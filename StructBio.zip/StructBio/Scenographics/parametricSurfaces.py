import chimera, numpy as np

from StructBio.Scenographics.lines import Lines
from StructBio.Scenographics.surfaces import Surfaces

#==============================================================================
# BASE CLASS
#==============================================================================
class ParametricSurface(object):
    def __init__(self, baseCurvePts_L, modelName = ""):
        self.modelName = modelName

        # Data structures at this level will track surface components that are common to
        # all surfaces: Frenet frame, extrusion, revolutionSurface, ruledSurface
        self.baseCurvePts_L = baseCurvePts_L
        self.numBasePts = len(baseCurvePts_L)

        self.crossSections_L = []
        self.meshLines = None
        self.surface = None

    # ----------------------------------------------------------------------
    def rotateAndMove(self, rotMat, translationVector):
        for csEntry in self.crossSections_L:
            for i in range(self.numBasePts):
                csEntry[i, :] = np.dot(rotMat, csEntry[i, :]) + translationVector

    # ----------------------------------------------------------------------
    def removeMesh(self):
        chimera.openModels.close([self.meshLines.vrmlModel])

    # ----------------------------------------------------------------------
    def removeSurface(self):
        chimera.openModels.close([self.surface.m])
        
    # ----------------------------------------------------------------------
    def displayMesh(self, color, closedBase = False,
                    startCap = False, endCap = False, closedSpine = False):
        if self.meshLines != None: self.removeMesh()
        self.meshLines = Lines(modelName = self.modelName + " mesh")
        if closedBase and startCap:
            for pt in self.crossSections_L[0]:
                cent = sum(self.crossSections_L[0])/self.numBasePts
                self.meshLines.addLine([cent, pt], color)
        if closedBase and endCap:
            for pt in self.crossSections_L[-1]:
                cent = sum(self.crossSections_L[-1])/self.numBasePts
                self.meshLines.addLine([cent, pt], color)

        # Put in lines that define cross section polygon:
        for cSect in self.crossSections_L:
            pts_L = list(cSect)
            if closedBase: pts_L.append(cSect[0])
            self.meshLines.addLine(pts_L, color)

        # Put in lines "parallel" to spine path:
        for i in range(self.numBasePts):
            pts_L = [cSect[i] for cSect in self.crossSections_L]
            if closedSpine: pts_L.append(self.crossSections_L[0][i])
            self.meshLines.addLine(pts_L, color)

        self.meshLines.display()

    # ----------------------------------------------------------------------
    def displaySurface(self, color, transparency = 1.0, closedBase = False,
                       startCap = False, endCap = False, closedSpine = False):
        if self.surface != None: self.removeSurface()
        self.surface = Surfaces(modelName = self.modelName + " surface")
        if closedBase and startCap:
            self.surface.addPolygon(self.crossSections_L[0], color, transparency = transparency)
        if closedBase and endCap:
            self.surface.addPolygon(self.crossSections_L[-1], color, transparency = transparency)

        for i in range(len(self.crossSections_L) - 1):
            for j in range(self.numBasePts - 1):
                self.surface.addPolygon([self.crossSections_L[i][j], self.crossSections_L[i][j+1],
                                    self.crossSections_L[i+1][j+1], self.crossSections_L[i+1][j]],
                                   color,  transparency = transparency)
            if closedBase:
                self.surface.addPolygon([self.crossSections_L[i][-1], self.crossSections_L[i][0],
                                    self.crossSections_L[i+1][0], self.crossSections_L[i+1][-1]],
                                   color,  transparency = transparency)
        if closedSpine:
            for j in range(self.numBasePts - 1):
                self.surface.addPolygon([self.crossSections_L[-1][j], self.crossSections_L[-1][j+1],
                                    self.crossSections_L[0][j+1], self.crossSections_L[0][j]],
                                   color,  transparency = transparency)
            if closedBase:
                self.surface.addPolygon([self.crossSections_L[-1][-1], self.crossSections_L[-1][0],
                                    self.crossSections_L[0][0], self.crossSections_L[0][-1]],
                                   color,  transparency = transparency)
        self.surface.display()

    # ----------------------------------------------------------------------
    def showSurface(self):
        self.surface.show()

    # ----------------------------------------------------------------------
    def hideSurface(self):
        self.surface.hide()                       

    # ----------------------------------------------------------------------
    def showMesh(self):
        self.meshLines.show()

    # ----------------------------------------------------------------------
    def hideMesh(self):
        self.meshLines.hide()
        
#==============================================================================
# DERIVED CLASSES
#==============================================================================
#------------------------------------------------------------------------------
# FrenetSurface CLASS
#------------------------------------------------------------------------------        
class FrenetFrameSurface(ParametricSurface):
    def __init__(self, baseCurvePts_L, spinePts_L, rotation3Dmats_L, xScale_L, yScale_L, modelName = ""):
        self.modelName = modelName
        ParametricSurface.__init__(self, baseCurvePts_L, modelName = self.modelName)

        self.spinePts_L = spinePts_L
        
        # If any of the next three lists contain just one entry then we assume that this one
        # entry is to be used with each member of the spinePts_L list.
        # If a list is empty then the corresponding operation is omitted.
        self.rotation3Dmats_L = rotation3Dmats_L
        self.xScale_L = xScale_L
        self.yScale_L = yScale_L

        numSP = len(spinePts_L)
        numRM = len(rotation3Dmats_L)
        numXS = len(xScale_L)
        numYS = len(yScale_L)

        # Some checks for incompatible list lengths:
        if numSP > 1 and numRM > 1 and numSP != numRM:
            print "Mismatch in lengths of spine points list and rotation matrix list"
            return
        if numSP > 1 and numXS > 1 and numSP != numXS:
            print "Mismatch in lengths of spine points list and xScale list"
            return
        if numSP > 1 and numYS > 1 and numSP != numYS:
            print "Mismatch in lengths of spine points list and yScale list"
            return
        
        rM = None; xS = None; yS = None     # These persist if their corresponding input list is empty.
        for k in range(numSP):
            if numRM == 1: rM = self.rotation3Dmats_L[0]
            if numRM > 1: rM = self.rotation3Dmats_L[k]
            if numXS == 1: xS = self.xScale_L[0]
            if numXS > 1: xS = self.xScale_L[k]
            if numYS == 1: yS = self.yScale_L[0]
            if numYS > 1: yS = self.yScale_L[k]
            self.crossSections_L.append(self.crossSection(rM, self.spinePts_L[k], xS, yS))
            
    # ----------------------------------------------------------------------
    def crossSection(self, rotation_M, spinePt_A, xScale, yScale):
        points_A = np.copy(self.baseCurvePts_L)    # Each row is an (x,y) point for the cross section.
        if xScale and xScale != 1.0: points_A[:, 0] *= xScale
        if yScale and yScale != 1.0: points_A[:, 1] *= yScale

        csPts_A = np.zeros((self.numBasePts, 3))

        for i in range(self.numBasePts):
            csPts_A[i, 0:2] = points_A[i, :]
            if rotation_M != None: csPts_A[i, :] = np.dot(rotation_M, csPts_A[i, :])
            csPts_A[i, :] += spinePt_A
        return csPts_A

#------------------------------------------------------------------------------
# ExtrusionSurface CLASS
#------------------------------------------------------------------------------        
class ExtrusionSurface(FrenetFrameSurface):
    def __init__(self, baseCurvePts_L, zMin, zMax, numCrossSections, rotation2Dmats_L, xScale_L, yScale_L, modelName = ""):
        self.modelName = modelName
        if numCrossSections < 2: numCrossSections = 2
        zIncr = float(zMax - zMin)/float(numCrossSections - 1)
        spinePts_L = [np.array([0.0, 0.0, x]) for x in np.arange(zMin, zMax + zIncr, zIncr)]
        rotation3Dmats_L = []
        if len(rotation2Dmats_L) > 0:
            for i in range(len(rotation2Dmats_L)):
                rotMat = np.zeros((3,3), float)
                rotMat[0:2, 0:2] = rotation2Dmats_L[i]
                rotation3Dmats_L.append(rotMat)
            
        FrenetFrameSurface.__init__(self, baseCurvePts_L, spinePts_L, rotation3Dmats_L, xScale_L, yScale_L, modelName = self.modelName)

    # The displayMesh and displaySurface functions assume that we never have a closed spine for a linear extrusion.
    # ----------------------------------------------------------------------
    def displayMesh(self, color, closedBase = False, startCap = False, endCap = False):
        FrenetFrameSurface.displayMesh(self, color, closedBase = closedBase,
                                       startCap = startCap, endCap = endCap, closedSpine = False)

    # ----------------------------------------------------------------------        
    def displaySurface(self, color, transparency = 1.0, closedBase = False, startCap = False, endCap = False):
        FrenetFrameSurface.displaySurface(self, color, transparency, closedBase = closedBase,
                                          startCap = startCap, endCap = endCap, closedSpine = False)

#------------------------------------------------------------------------------
# RevolutionSurface CLASS
#------------------------------------------------------------------------------        
class RevolutionSurface(FrenetFrameSurface):
    def __init__(self, baseCurvePts_L, thetaMin, thetaMax, numCrossSections, xScale_L, yScale_L, modelName = ""):
        self.modelName = modelName
        if numCrossSections < 2: numCrossSections = 2
        thetaIncr = float(thetaMax - thetaMin)/float(numCrossSections - 1)
        thetaVals_L = [t for t in np.arange(thetaMin, thetaMax + thetaIncr, thetaIncr)] 
        spinePts_L = [np.array([0.0, 0.0, 0.0]) for i in range(len(thetaVals_L))]

        # Prepare matrices to rotate base curve around the y - axis:                       
        rotation3Dmats_L = []
        for theta in thetaVals_L:
            rotation3Dmats_L.append(np.array([[np.cos(theta), 0.0, -np.sin(theta)],
                                             [0.0, 1.0, 0.0],
                                             [np.sin(theta), 0.0, np.cos(theta)]]))                        
            
        FrenetFrameSurface.__init__(self, baseCurvePts_L, spinePts_L, rotation3Dmats_L, xScale_L, yScale_L, modelName = self.modelName)


#------------------------------------------------------------------------------
# RuledSurface CLASS
#------------------------------------------------------------------------------        
class RuledSurface(ParametricSurface):
    def __init__(self, firstCurvePts_L, finalCurvePts_L, numCrossSections, modelName = ""):
        self.modelName = modelName
        if numCrossSections < 2: numCrossSections = 2
        numFirstPts = len(firstCurvePts_L)
        if numFirstPts != len(finalCurvePts_L): 
            print "Mismatch in lengths of first points list and final points list"
            return
        ParametricSurface.__init__(self, firstCurvePts_L, modelName = self.modelName)

        # Compute line segments (one for each straignt line in the surface):
        segments_L = [(finalCurvePts_L[i] - firstCurvePts_L[i])/(numCrossSections - 1)
                      for i in range(numFirstPts)]
        
        # Generate cross sections.  Each point in cross section i is at the end of i line segments.
        self.crossSections_L = []
        for i in range(numCrossSections):
            csPts_A = np.zeros((numFirstPts, 3))
            for j in range(numFirstPts):
                csPts_A[j, :] = firstCurvePts_L[j] + i * segments_L[j]
            self.crossSections_L.append(csPts_A)
        
    # The displayMesh and displaySurface functions assume that we never have a closed spine.
    # ----------------------------------------------------------------------
    def displayMesh(self, color, closed = False, startCap = False, endCap = False):
        ParametricSurface.displayMesh(self, color, closedBase = closed,
                                      startCap = startCap, endCap = endCap, closedSpine = False)

    # ----------------------------------------------------------------------        
    def displaySurface(self, color, transparency = 1.0, closed = False, startCap = False, endCap = False):
        ParametricSurface.displaySurface(self, color, transparency, closedBase = closed,
                                          startCap = startCap, endCap = endCap, closedSpine = False)
