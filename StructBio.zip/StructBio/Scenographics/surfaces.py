import chimera, numpy, _surface
from chimera import runCommand
from numpy import array, math
from CGLutil import vrml

# This class places geometric solids in the display.
# Data types are as follows:
#   rgb designate a color.  It is a 3-tuple containing floating point numbers
#       each in the range [0.0, 1.0].
#   transparency is a number in the range [0.0, 1.0].
#   polyPoints_L is a list of arrays each representing the 3D coordinates of a
#       vertex in a polygon.
 
#==============================================================================
#  SURFACES CLASS 
#==============================================================================
class Surfaces(object):
    def __init__(self, modelName = "Surfaces graphics"):
        self.modelName = modelName
        self.wrl = vrml.Transform()
        self.m = _surface.SurfaceModel()
        self.m.name = self.modelName
        self.vrmlFlag = False   # Using vrml indicator
        self.surfFlag = False   # Using surface indicator
        self.vrmlModId = None
        self.surfModId = None
        self.faces = vrml.Faces()


#==============================================================================
#  Surfaces based on VRML.
#==============================================================================
    # Generate VRML string that draws a linking strut (drawn as a long cylinder).
    def addFace(self, polyPoints_L, rgb):
        self.vrmlFlag = True
        self.faces.addFace(polyPoints_L, rgb)
        self.wrl.addChild(self.faces)


# =================================================================================
# Surfaces using _surface
# =================================================================================
                
    # Input is a list of 3D arrays.  Each array represents the coordinates of a point
    # in the display.
    def addPolygon(self, polyPoints_L, rgb, transparency = 1.0):
        self.surfFlag = True
        cr = (rgb[0], rgb[1], rgb[2], transparency)
        numVertices = len(polyPoints_L)
        v = [sum(polyPoints_L, 0)/numVertices] # Start vertex list with centroid.
        for entry in polyPoints_L:
            v.append(entry)
        for ix in range(numVertices - 1):
            vTriangle = [(0, ix + 1, ix + 2)]
            self.m.addPiece(v, vTriangle, cr)
        vTriangle = [(0, numVertices, 1)]  # Do last triangle
        self.m.addPiece(v, vTriangle, cr)

    
#==================================================================================        -
    def display(self):
        if self.vrmlFlag:
            self.vrmlModel = chimera.openModels.open(vrml.vrml(self.wrl), 'VRML')[0]
            self.vrmlModId = self.vrmlModel.id
            self.vrmlModel.name = self.modelName
        if self.surfFlag:
            chimera.openModels.add([self.m])
            self.surfModId = self.m.id

#==================================================================================        -
    def show(self):
        if self.vrmlFlag: runCommand("modeldisplay #" + str(self.vrmlModId))       
        if self.surfFlag: runCommand("modeldisplay #" + str(self.surfModId))        

#==================================================================================        -
    def hide(self):
        if self.vrmlFlag: runCommand("~modeldisplay #" + str(self.vrmlModId))       
        if self.surfFlag: runCommand("~modeldisplay #" + str(self.surfModId))        

















