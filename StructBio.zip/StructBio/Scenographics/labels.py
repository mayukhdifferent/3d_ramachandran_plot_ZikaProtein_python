import chimera
from chimera import openModels, Molecule, Element, Coord
from chimera.colorTable import getColorByName

#=========================================================================
class LabelGroups(object):
    def __init__(self, labelGroupsName = "Labels"):

        self.labelGroups = Molecule()
        self.labelGroups.name = labelGroupsName

    #-------------------------------------------------------------------
    def addLabelGroup(self, groupName):
        # groupName must be a string.
        self.labelGroups.newResidue(groupName, " ", 1, " ")

    #-------------------------------------------------------------------
    def addLabel(self, groupName, label, coords_T):
        # label must be a string.
        labelGroup = [r for r in self.labelGroups.residues if r.type == groupName][0]
        labelGroup.addAtom(self._atom(label, coords_T))

    #-------------------------------------------------------------------
    def setLabels(self, groupName, colorName, stride = 1):
        labelGroup = [r for r in self.labelGroups.residues if r.type == groupName][0]
        ix = 0
        for a in labelGroup.atoms:
            a.label = ""
            if ix%stride == 0:
                a.label = a.name
                a.labelColor = getColorByName(colorName)
            ix += 1

    #-------------------------------------------------------------------        
    def showLabels(self):
        openModels.add([self.labelGroups])

    #-------------------------------------------------------------------
    def clearLabels(self, groupName):
        labelGroup = [r for r in self.labelGroups.residues if r.type == groupName][0]
        for a in labelGroup.atoms:
            a.label = ""

    #-------------------------------------------------------------------
    def destroyLabels(self):
        # Destroys all labels and the virtual atoms associated with them.
        openModels.close([self.labelGroups])

    #-------------------------------------------------------------------
    def _atom(self, aName, coords_T):
        a = self.labelGroups.newAtom(aName, Element("Label"))
        a.setCoord(Coord(coords_T[0], coords_T[1], coords_T[2]))
        a.radius = 0.00001
        a.labelOffset = chimera.Vector(0.0, 0.0, 0.0)
        return a



