import chimera, numpy
from chimera import runCommand
from numpy import array
from CGLutil import vrml

# This class places segmented lines in the display.
# Data types are as follows:
#   rgb designate a color.  It is a 3-tuple containing floating point numbers
#       each in the range [0.0, 1.0].
#   points_L is a list of arrays each representing the 3D coordinates of a
#       vertex in a sequence of joined line segments.
 
#==============================================================================
#  LINES CLASS 
#==============================================================================
class Lines(object):
    def __init__(self, modelName = "Lines graphics"):
        self.modelName = modelName
        self.wrl = vrml.Transform()
        self.vrmlModId = None
        self.lines = vrml.Lines()


    # Generate VRML string that draws a linking strut (drawn as a long cylinder).
    def addLine(self, points_L, rgb):
        self.lines.addLine(points_L, rgb)
        self.wrl.addChild(self.lines)

    
#==================================================================================        -
    def display(self):
        self.vrmlModel = chimera.openModels.open(vrml.vrml(self.wrl), 'VRML')[0]
        self.vrmlModId = self.vrmlModel.id
        self.vrmlModel.name = self.modelName

#==================================================================================        -
    def show(self):
        runCommand("modeldisplay #" + str(self.vrmlModId))               

#==================================================================================        -
    def hide(self):
        runCommand("~modeldisplay #" + str(self.vrmlModId))       
        


















