import numpy as np
from StructBio.Scenographics.parametricSurfaces import RevolutionSurface

#==============================================================================
# Ellipsoid CLASS
#==============================================================================
class Ellipsoid(RevolutionSurface):
    # The lenght is the longest dimension, width is next and height is the shortest.
    def __init__(self, length, width, height, center, axes_L, numCrossSections, numBasePts, ellipsoidName = "Ellipsoid"):
        self.ellipsoidName = ellipsoidName
        # Set up elliptical profile in x >= 0 half of x,y plane.
        psiIncr = np.pi/(numBasePts - 1)
        psiVals_L = [i*psiIncr - np.pi/2.0 for i in range(numBasePts)]
        basePts_L = [np.array([np.cos(psi), length * np.sin(psi)]) for psi in psiVals_L]

        # compute xScale values that are needed during revolution:
        # Note: in a parametric representation of a circle (x = r cos(t), y = r sin(t))
        # the parameter t corresponds to the
        # angle between the x-axis and the radial vector.  This is not true for a parametric
        # representation of an ellipse! So, we must convert each theta value (used in the rotation
        # matrices) to a parameter value t.
        thetaIncr = 2.0 * np.pi/numCrossSections
        thetaVals_L = [i*thetaIncr for i in range(numCrossSections)]
        xScales_L = np.zeros(numCrossSections, float)
        xScales_L[0] = xScales_L[numCrossSections/2] = height
        xScales_L[numCrossSections/4] = xScales_L[-numCrossSections/4] = width
        for i in range(1, numCrossSections/4):
            t = np.arctan(height*np.tan(thetaVals_L[i])/width)
            func_t = np.sqrt(height*height * np.cos(t)**2 + width*width * np.sin(t)**2)
            xScales_L[i] = xScales_L[-i] = xScales_L[numCrossSections/2 - i] = xScales_L[-numCrossSections/2 + i] = func_t

        RevolutionSurface.__init__(self, basePts_L, 0.0, 2.*np.pi - thetaIncr, numCrossSections,
                                   xScales_L, [], modelName = self.ellipsoidName)

        orientation_M = np.array(axes_L).transpose()
        rot_M = np.zeros((3,3))
        rot_M[:, 2] = orientation_M[:, 1]
        rot_M[:, 1] = orientation_M[:, 0]
        rot_M[:, 0] = orientation_M[:, 2]
        RevolutionSurface.rotateAndMove(self, rot_M, center)


    # -----------------------------------------------------------------------------
    def displayMesh(self, color):
        RevolutionSurface.displayMesh(self, color, startCap = False, endCap = False, closedBase = False, closedSpine = True)


    # -----------------------------------------------------------------------------
    def displaySurface(self, color, transparency = 1.):
        RevolutionSurface.displaySurface(self, color, transparency = transparency, startCap = False, endCap = False,
                              closedBase = False, closedSpine = True)







