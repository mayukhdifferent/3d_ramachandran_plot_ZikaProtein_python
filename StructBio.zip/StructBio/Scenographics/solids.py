import chimera, numpy, _surface
from chimera import runCommand
from numpy import array, math
from CGLutil import vrml

# This class places geometric solids in the display.
# Data types are as follows:
#   p1, p2, center are arrays that hold coordinates for 3D points.
#   radius, side, thickness  are floating point positive numbers.
#   rgb designate a color.  It is a 3-tuple containing floating point numbers
#       each in the range [0.0, 1.0].
#   transparency is a number in the range [0.0, 1.0].
#   normal is an array that holds a 3 component vector that designates a direction.
#   sides_T is a tuple that holds three floating point positive numbers representing
#       the lengths of a box.
 
#==============================================================================
#  SOLIDS CLASS 
#==============================================================================
class Solids(object):
    def __init__(self, modelName = "Solids graphics"):
        self.modelName = modelName
        self.wrl = vrml.Transform()
        self.m = _surface.SurfaceModel()
        self.m.name = self.modelName
        self.vrmlFlag = False   # Using vrml indicator
        self.surfFlag = False   # Using surface indicator
        self.vrmlModId = None
        self.surfModId = None


#==============================================================================
#  Solids based on VRML.
#==============================================================================
    # Generate VRML string that draws a linking strut (drawn as a long cylinder).
    def addStrut(self, p1, p2, radius, rgb):
        self.vrmlFlag = True
        c = self.__cylinder_node(p1, p2, radius, rgb)
        self.wrl.addChild(c)


    # -----------------------------------------------------------------------------
    # Generate VRML string that draws a capped tube.
    # A spheres is drawn at the end point to provide a tube cap.
    # The begin point of the cylinder has a flat bottom cap.
    def addTube(self, p1, p2, radius, rgb):
        self.vrmlFlag = True
        translate = vrml.Transform(translation = tuple(p2))
        s = vrml.Sphere(radius = radius, color = rgb)
        translate.addChild(s)
        self.wrl.addChild(translate)
        c = self.__cylinder_node(p1, p2, radius, rgb)
        self.wrl.addChild(c)

        
    # -----------------------------------------------------------------------------
    # Return VRML node for a cylinder with axis specified by end points.
    def __cylinder_node(self, p1, p2, radius, rgb):
        self.vrmlFlag = True
        transform = vrml.Transform()
        axis = p2 - p1
        length = numpy.linalg.norm(axis)
        if length > 0:
            center = .5 * (p1 + p2)
            translate = vrml.Transform(translation=tuple(center))
            transform.addChild(translate)
            rot_axis = (axis[2], 0, -axis[0])
            rot_angle = math.atan2(math.sqrt(axis[0]*axis[0] + axis[2]*axis[2]), axis[1])
            rotate = vrml.Transform(rotation=rot_axis + (rot_angle,))
            translate.addChild(rotate)
            cylinder = vrml.Cylinder(radius=radius, height=length, color=rgb,
                                 top = 1, bottom = 1)
            rotate.addChild(cylinder)
        return transform

    # -----------------------------------------------------------------------------
    # Generate VRML string that draws a sphere.
    def addSphere(self, center, radius, rgb):
        self.vrmlFlag = True
        translate = vrml.Transform(translation = tuple(center))
        s = vrml.Sphere(radius = radius, color = rgb)
        translate.addChild(s)
        self.wrl.addChild(translate)

    # -----------------------------------------------------------------------------
    # Generate VRML string that draws a cube.
    def addCube(self, center, side, rgb):
        self.vrmlFlag = True
        translate = vrml.Transform(translation = tuple(center))
        s = vrml.Box(size = (side, side, side), color = rgb)
        translate.addChild(s)
        self.wrl.addChild(translate)

    # -----------------------------------------------------------------------------
    # Generate VRML string that draws a box.
    def addBox(self, center, sides_T, rgb):
        self.vrmlFlag = True
        translate = vrml.Transform(translation = tuple(center))
        s = vrml.Box(size = sides_T, color = rgb)
        translate.addChild(s)
        self.wrl.addChild(translate)

    # -----------------------------------------------------------------------------
    # Return VRML node for a disk with specified center and orientation given by a normal.
    def addDisk(self, center, normal, thickness, radius, rgb):
        self.vrmlFlag = True
        transform = vrml.Transform()
        axis = thickness * normal
        if thickness > 0:
            translate = vrml.Transform(translation = tuple(center))
            transform.addChild(translate)
            rot_axis = (axis[2], 0, -axis[0])
            rot_angle = math.atan2(math.sqrt(axis[0]*axis[0] + axis[2]*axis[2]), axis[1])
            rotate = vrml.Transform(rotation = rot_axis + (rot_angle,))
            translate.addChild(rotate)
            cylinder = vrml.Cylinder(radius = radius, height = thickness, color = rgb,
                                 top = 1, bottom = 1)
            rotate.addChild(cylinder)
        self.wrl.addChild(transform)

    # -----------------------------------------------------------------------------
    # Return VRML node for a spindle with axis specified by end points.
    def addSpindle(self, p1, p2, radius, rgb):
        self.vrmlFlag = True
        transform = vrml.Transform()
        axis = p2 - p1
        length = numpy.linalg.norm(axis) - 8.0 * radius
        if length > 0:
            center = .5 * (p1 + p2)
            translate = vrml.Transform(translation = tuple(center))
            transform.addChild(translate)
            rot_axis = (axis[2], 0, -axis[0])
            rot_angle = math.atan2(math.sqrt(axis[0]*axis[0] + axis[2]*axis[2]), axis[1])
            rotate = vrml.Transform(rotation = rot_axis + (rot_angle,))
            translate.addChild(rotate)
            cylinder = vrml.Cylinder(radius = radius, height = length, color = rgb,
                                 top = 1, bottom = 1)
            rotate.addChild(cylinder)
        self.wrl.addChild(transform)

        # Put in slender cones for the spindle ends.
        for t in ((p2, (p2-p1)), (p1, (p1 - p2))):
            axis = t[1]
            cCenter = t[0] - 2.*radius * axis/numpy.linalg.norm(axis)            
            cTransform = vrml.Transform()
            cTranslate = vrml.Transform(translation = tuple(cCenter))
            cTransform.addChild(cTranslate)
            rot_axis = (axis[2], 0, -axis[0])
            rot_angle = math.atan2(math.sqrt(axis[0]*axis[0] + axis[2]*axis[2]), axis[1])
            cRotate = vrml.Transform(rotation = rot_axis + (rot_angle,))
            cTranslate.addChild(cRotate)
            c = vrml.Cone(bottomRadius = radius, height = 4.0*radius, color = rgb, side = 1)
            cRotate.addChild(c)
            self.wrl.addChild(cTransform)

    # -----------------------------------------------------------------------------
    # Return VRML node for an arrow with axis specified by end points.
    # The arrow tip has a conical base centered on p2.
    def addArrow(self, p1, p2, radius, rgb):
        self.vrmlFlag = True
        transform = vrml.Transform()
        axis = p2 - p1
        length = numpy.linalg.norm(axis) # - 8.0 * radius
        if length > 0:
            center = .5 * (p1 + p2)
            translate = vrml.Transform(translation = tuple(center))
            transform.addChild(translate)
            rot_axis = (axis[2], 0, -axis[0])
            rot_angle = math.atan2(math.sqrt(axis[0]*axis[0] + axis[2]*axis[2]), axis[1])
            rotate = vrml.Transform(rotation = rot_axis + (rot_angle,))
            translate.addChild(rotate)
            cylinder = vrml.Cylinder(radius = radius, height = length, color = rgb,
                                 top = 1, bottom = 1)
            rotate.addChild(cylinder)
        self.wrl.addChild(transform)

        # Put in cone for the arrow tip.
        axis = p2 - p1
        cCenter = p2 + 2.*radius * axis/numpy.linalg.norm(axis)            
        cTransform = vrml.Transform()
        cTranslate = vrml.Transform(translation = tuple(cCenter))
        cTransform.addChild(cTranslate)
        rot_axis = (axis[2], 0, -axis[0])
        rot_angle = math.atan2(math.sqrt(axis[0]*axis[0] + axis[2]*axis[2]), axis[1])
        cRotate = vrml.Transform(rotation = rot_axis + (rot_angle,))
        cTranslate.addChild(cRotate)
        c = vrml.Cone(bottomRadius = 2.0*radius, height = 4.0*radius, color = rgb, side = 1)
        cRotate.addChild(c)
        self.wrl.addChild(cTransform)


# =================================================================================
# Solids using _surface
# =================================================================================

    def addTetrahedron(self, center, size, rgb, transparency = 1.0):
        self.surfFlag = True
        from numpy import array as a
        cr = (rgb[0], rgb[1], rgb[2], transparency)
        c = center
        s = size
        vertices_L = [a((1., 1., 1.))*s+c, a((-1., -1., 1.))*s+c,
                      a((-1., 1., -1.))*s+c, a((1., -1., -1.))*s+c]
        triangles_L = []
        triangles_L.append([(0, 1, 2)]); triangles_L.append([(1, 2, 3)])
        triangles_L.append([(2, 3, 0)]); triangles_L.append([(3, 0, 1)])

        for triangle in triangles_L:
            self.m.addPiece(vertices_L, triangle, cr)


    # -----------------------------------------------------------------------------
    def addHexahedron(self, center, size, rgb, transparency = 1.0):
        self.surfFlag = True
        from numpy import array as a
        cr = (rgb[0], rgb[1], rgb[2], transparency)
        c = center
        s = size
        vertices_L = [a((-1., -1., -1.))*s+c, a((-1., -1., 1.))*s+c,
                      a((-1., 1., -1.))*s+c, a((-1., 1., 1.))*s+c,
                      a((1., -1., -1.))*s+c, a((1., -1., 1.))*s+c,
                      a((1., 1., -1))*s+c, a((1., 1., 1.))*s+c]
        triangles_L = []
        triangles_L.append([(0, 1, 3)]); triangles_L.append([(0, 2, 3)])
        triangles_L.append([(0, 1, 5)]); triangles_L.append([(0, 4, 5)])
        triangles_L.append([(0, 2, 6)]); triangles_L.append([(0, 4, 6)])
        triangles_L.append([(7, 3, 1)]); triangles_L.append([(7, 5, 1)])
        triangles_L.append([(7, 5, 4)]); triangles_L.append([(7, 6, 4)])
        triangles_L.append([(7, 3, 2)]); triangles_L.append([(7, 6, 2)])
        
        for triangle in triangles_L:
            self.m.addPiece(vertices_L, triangle, cr)
           

    # -----------------------------------------------------------------------------
    def addOctahedron(self, center, size, rgb, transparency = 1.0):
        self.surfFlag = True
        from numpy import array as a
        cr = (rgb[0], rgb[1], rgb[2], transparency)
        c = center
        s = size
        vertices_L = [a((0., 0., 1.))*s+c, a((1., 0., 0.))*s+c, a((0., -1., 0.))*s+c,
                      a((-1., 0., 0.))*s+c, a((0., 1., 0))*s+c, a((0., 0., -1.))*s+c]
        triangles_L = []
        triangles_L.append([(0, 1, 2)]); triangles_L.append([(0, 2, 3)])
        triangles_L.append([(0, 3, 4)]); triangles_L.append([(0, 4, 1)])
        triangles_L.append([(5, 1, 2)]); triangles_L.append([(5, 2, 3)])
        triangles_L.append([(5, 3, 4)]); triangles_L.append([(5, 4, 1)])

        for triangle in triangles_L:
            self.m.addPiece(vertices_L, triangle, cr)
           

    # -----------------------------------------------------------------------------
    def addDodecahedron(self, center, size, rgb, transparency = 1.0):
        self.surfFlag = True
        from numpy import array as a
        cr = (rgb[0], rgb[1], rgb[2], transparency)

        t = (1. + 5.**.5)/2.  # t for tau the golden ratio.
        u = [a((i, j, k), float)*size+center for i in (-1,1) for j in (-1,1) for k in (-1,1)]
        x = [a((0, i*t, j/t), float)*size+center for i in (-1,1) for j in (-1,1)]
        y = [a((i/t, 0, j*t), float)*size+center for i in (-1,1) for j in (-1,1)]
        z = [a((i*t, j/t, 0), float)*size+center for i in (-1,1) for j in (-1,1)]

        poly_L = []
        poly_L.append([x[0], u[4], z[2], u[5], x[1]])
        poly_L.append([x[1], u[1], z[0], u[0], x[0]])
        poly_L.append([x[2], u[2], z[1], u[3], x[3]])
        poly_L.append([x[3], u[7], z[3], u[6], x[2]])
        poly_L.append([y[0], u[0], x[0], u[4], y[2]])        
        poly_L.append([y[1], u[3], x[3], u[7], y[3]])
        poly_L.append([y[2], u[6], x[2], u[2], y[0]])        
        poly_L.append([y[3], u[5], x[1], u[1], y[1]])
        poly_L.append([z[0], u[0], y[0], u[2], z[1]])
        poly_L.append([z[1], u[3], y[1], u[1], z[0]])
        poly_L.append([z[2], u[5], y[3], u[7], z[3]])
        poly_L.append([z[3], u[6], y[2], u[4], z[2]])

        for poly in poly_L:
            v = [sum(poly, 0)/5.]
            for entry in poly:
                v.append(entry)
            for ix in range(4):
                vTriangle = [(0, ix + 1, ix + 2)]
                self.m.addPiece(v, vTriangle, cr)
            vTriangle = [(0, 5, 1)]  # Do last triangle
            self.m.addPiece(v, vTriangle, cr)
            

    # -----------------------------------------------------------------------------
    def addIcosahedron(self, center, size, rgb, transparency = 1.0):
        self.surfFlag = True
        cr = (rgb[0], rgb[1], rgb[2], transparency)
        t = (1. + 5.**.5)/2.  # t for tau the golden ratio.
        # Build vertex list and index dictionary:
        v = []
        ix_D = {}

        i = 0
        for r in (-1., 1.):
            for s in (-t, t):
                v.append(array([0., s*size, r*size]) + center); ix_D[(0., s, r)] = i; i += 1
                v.append(array([r*size, 0., s*size]) + center); ix_D[(r, 0., s)] = i; i += 1
                v.append(array([s*size, r*size, 0.]) + center); ix_D[(s, r, 0.)] = i; i += 1

        # Add in the 8 "quadrant" positioned triangles:
        for p in (-1., 1.):
            for q in (-1., 1.):
                for r in (-1., 1.):
                    v1 = (p*t, q, 0.)
                    v2 = (p, 0., r*t)
                    v3 = (0., q*t, r)
                    self.m.addPiece(v, [(ix_D[v1], ix_D[v2], ix_D[v3])], cr)

        # Add in the 12  triangles, each having one "short" edge (b1, b2) from a Borromean ring.
        # Each short edge (b1, b2) will have a long edge (u3, u4) underneath it (from a perpendicular ring).
        for rx in (0,1,2):      #This identifies a Borromean ring (index of the zero entry).
            for st in (-1., 1.): # This is the sign for tau.
                b1 = [0., 0., 0.]; b2 = [0., 0., 0.]; u3 = [0., 0., 0.]; u4 = [0., 0., 0.]
                b1[(rx - 1)%3] = 1.; b2[(rx - 1)%3] = -1.
                b1[(rx + 1)%3] = b2[(rx + 1)%3] = st*t
                u3[rx] = t; u4[rx] = -t
                u3[(rx + 1)%3] = u4[(rx + 1)%3] = st
                b1 = tuple(b1); b2 = tuple(b2); u3 = tuple(u3); u4 = tuple(u4); 
                self.m.addPiece(v, [(ix_D[b1], ix_D[b2], ix_D[u3])], cr)
                self.m.addPiece(v, [(ix_D[b1], ix_D[b2], ix_D[u4])], cr)

    
#==================================================================================        -
    def display(self):
        if self.vrmlFlag:
            self.vrmlModel = chimera.openModels.open(vrml.vrml(self.wrl), 'VRML')[0]
            self.vrmlModId = self.vrmlModel.id
            self.vrmlModel.name = self.modelName
        if self.surfFlag:
            chimera.openModels.add([self.m])
            self.surfModId = self.m.id

#==================================================================================        -
    def show(self):
        if self.vrmlFlag: runCommand("modeldisplay #" + str(self.vrmlModId))       
        if self.surfFlag: runCommand("modeldisplay #" + str(self.surfModId))        

#==================================================================================        -
    def hide(self):
        if self.vrmlFlag: runCommand("~modeldisplay #" + str(self.vrmlModId))       
        if self.surfFlag: runCommand("~modeldisplay #" + str(self.surfModId))        

