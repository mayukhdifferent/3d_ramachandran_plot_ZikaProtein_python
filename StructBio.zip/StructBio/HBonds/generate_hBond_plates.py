import chimera, numpy
from chimera import runCommand
from numpy import array
from StructBio.Scenographics.surfaces import Surfaces 

#==============================================================================
# Generate_hBond_plates CLASS
#==============================================================================

class Generate_hBond_plates(object):
    def __init__(self, proteinMolecule, hBondDicts,
                 color_PL_S = (.133, .545, .133, 0.9),
                 color_AP_S = (.392, .584, .929, 0.9),
                 color_PL_D = (.000,  1.0,  0.5, 0.9),
                 color_AP_D = (.529, .808, .922, 0.9)):
        self.hBs = hBondDicts
        self.prot = proteinMolecule
        self.color_PL_S = color_PL_S   # Colour for parallel same chain
        self.color_AP_S = color_AP_S   # Colour for anti-parallel same chain
        self.color_PL_D = color_PL_D   # Colour for parallel different chains
        self.color_AP_D = color_AP_D   # Colour for anti-parallel different chains
        self.__pd = Surfaces(modelName = "H-Bond Plates")
        
        for dn_acPair in self.hBs.hBondCategory_D.keys():
            if self.hBs.hBondCategory_D[dn_acPair] == "NA": continue
            if self.hBs.hBondCategory_D[dn_acPair] == "HE": continue
            donorA = dn_acPair[0]
            acptrA = dn_acPair[1]

            # Be sure flanking residues exist (we might be at the end of a chain):
            if not self.prot.residueBefore(donorA.residue): continue
            if not self.prot.residueBefore(donorA.residue).findAtom('CA'): continue
            if not self.prot.residueAfter(acptrA.residue): continue
            if not self.prot.residueAfter(acptrA.residue).findAtom('CA'): continue
            # Flanking residues must be in same chain:
            if not (self.prot.residueAfter(acptrA.residue).id.chainId == acptrA.residue.id.chainId): continue
            if not (self.prot.residueBefore(donorA.residue).id.chainId == donorA.residue.id.chainId): continue
            
            coordsCaInDonorRes = array(donorA.residue.findAtom('CA').coord())
            coordsCaInAcptrRes = array(acptrA.residue.findAtom('CA').coord())
            coordsCaBeforeDonorRes = array(self.prot.residueBefore(donorA.residue).findAtom('CA').coord())
            coordsCaAfterAcptrRes = array(self.prot.residueAfter(acptrA.residue).findAtom('CA').coord())

            bondCat = self.hBs.hBondCategory_D[dn_acPair]
            bondSameChain = self.hBs.hBondSameChain_D[dn_acPair]
            
            if (bondCat == "PL" or bondCat == "HE") and bondSameChain:
                color = self.color_PL_S[0:3]
                trans = self.color_PL_S[3]
            if bondCat == "AP" and bondSameChain:
                color = self.color_AP_S[0:3]
                trans = self.color_AP_S[3]
            if bondCat == "PL" and not bondSameChain:
                color = self.color_PL_D[0:3]
                trans = self.color_PL_D[3]
            if bondCat == "AP" and not bondSameChain:
                color = self.color_AP_D[0:3]
                trans = self.color_AP_D[3]

            if bondCat == "PL" or bondCat == "HE":
                v = [coordsCaBeforeDonorRes, coordsCaInDonorRes,
                     coordsCaAfterAcptrRes,coordsCaInAcptrRes]
            else:
                v = [coordsCaBeforeDonorRes, coordsCaInDonorRes,
                     coordsCaInAcptrRes, coordsCaAfterAcptrRes]
                
            self.__pd.addPolygon(v, color, trans)

        self.__pd.display()
        
        runCommand("set bg_color white")
        runCommand("~ribbon")
        runCommand("~select")
        runCommand("chain @ca")
        runCommand("repr stick")
        runCommand("display sel")
        runCommand("~select")     



                 
