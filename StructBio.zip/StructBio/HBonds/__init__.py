import generate_hBond_plates  # Make this visible for the package.

import chimera, numpy, FindHBond
from sets import Set

from chimera import runCommand
from numpy import array

from StructBio.Utilities.shellNeighbors import Shell
#==============================================================================
# HBondDicts CLASS
#==============================================================================

class HBondDicts(object):
    def __init__(self, prot, dist_Slop = 0.4, angle_Slop = 20.0):
        self.prot = prot
        self.__resToSScodeMap_D = {}

        # Next three dictionaries are useful for applications:
        self.hBond_D = {} # Key: donor atom. Value: list of acceptor atoms
        self.hBondSameChain_D = {}      # Key: (donor atom, acceptor atom) tuple
                                        # Value: True only if both donor and acceptor
                                        #        are in same chain.
        self.hBondCategory_D = {}     # Key: (donor atom, acceptor atom) tuple
                                      # Value: A category code:
                                      #        "HE": HElix
                                      #        "AP": beta strands running Anti-Parallel
                                      #        "PL": beta strands running in ParalleL
                                      #        "NA": Not Applicable (i.e. None of the Above)

        backBoneDonors_L = [] # To be used as an argument for findHBonds.


        # Build dictionary that does mapping of residue objects to secondary structure name.
        # Codes: H (Helix), S (Strand), C (Coil), T (Het)
        ssNum = 1
        r = self.prot.findResidue(0)
        curChainId = r.id.chainId
        curSScode = self.__SScode(r)
        while r:
            if r.findAtom("N"):
                backBoneDonors_L.append(r.findAtom("N"))
            rSScode = self.__SScode(r)
            if r.id.chainId == curChainId and rSScode == curSScode:
                self.__resToSScodeMap_D[r] = (rSScode, ssNum)
            else:
                ssNum += 1
                curChainId = r.id.chainId
                curSScode = rSScode
                self.__resToSScodeMap_D[r] = (rSScode, ssNum)
            r = self.prot.residueAfter(r)           
            
        # Select the backbone of the specified model:
        runCommand("select #" + str(self.prot.id)+ " & backbone.full")
        runCommand("findhbond selRestrict both distSlop %4.1f" % dist_Slop + " angleSlop %4.1f" % angle_Slop)
        runCommand("~sel")

        hb_L = FindHBond.findHBonds([prot], donors = backBoneDonors_L, distSlop = dist_Slop, angleSlop = angle_Slop)

        for hB_T in hb_L:
            if hB_T[0] in self.hBond_D.keys():
                self.hBond_D[hB_T[0]].append(hB_T[1])
            else:
                self.hBond_D[hB_T[0]] = [hB_T[1]]

        # Now characterize all the H bonds by filling in the dictionaries:
        for donorA in self.hBond_D.keys():
            for acptrA in self.hBond_D[donorA]:
                sameChainTF = donorA.residue.id.chainId == acptrA.residue.id.chainId
                self.hBondSameChain_D[(donorA, acptrA)] = sameChainTF
                self.hBondCategory_D[(donorA, acptrA)] = self.__categoryCode(donorA, acptrA)

    # -------------------------------------------------------------------------------------------
    def __categoryCode(self, donorAtom, acceptorAtom):
        code = "NA"
        donorRes = donorAtom.residue
        acptrRes = acceptorAtom.residue
        if not (donorAtom.name == "N"): return code
        if not (acceptorAtom.name == "O"): return code 
        if donorRes.isHelix and self.__resToSScodeMap_D[donorRes] == self.__resToSScodeMap_D[acptrRes]:
            code = "HE"
            return code

        try:
            acptr_L = self.hBond_D[acptrRes.findAtom('N')]
            for a in acptr_L:
                if a.residue.id.chainId == donorRes.id.chainId:
                    if a.residue.id.position == donorRes.id.position: code = "AP"
                    if a.residue.id.position == donorRes.id.position - 2: code = "PL"
        except:
            pass
        try:
            potentialDonor = self.prot.residueAfter(self.prot.residueAfter(acptrRes)).findAtom('N')
            if potentialDonor.residue.id.chainId == acptrRes.id.chainId:
                acptr_L = self.hBond_D[potentialDonor]
                for a in acptr_L:
                    if a.residue.id.chainId == donorRes.id.chainId:
                        if a.residue.id.position == donorRes.id.position: code = "PL"
                        if a.residue.id.position == donorRes.id.position - 2: code = "AP"
        except:
            pass
        return code
    
    # -------------------------------------------------------------------------------------------
    def __SScode(self, residue):
        cd = 'C'
        if residue.isHet: cd = 'T'
        if residue.isStrand: cd = 'S'
        if residue.isHelix: cd = 'H'
        return cd

#==============================================================================
# Dehydrons CLASS
#==============================================================================

class Dehydrons(object):
    def __init__(self, prot, distSlop = 0.4, angleSlop = 20.0, lineWidth = 5.0,
                 sphereRadius = 6.5, wrapThreshold = 19,  alphaCenters = True):

        self.dist_Slop = distSlop
        self.angle_Slop = angleSlop
        self.sphere_Radius = sphereRadius
        self.wrap_Threshold = wrapThreshold
        self.line_width = lineWidth
        self.alpha_Centers = alphaCenters
        
        self.hBonds_L = []
        self.dehydrons_L = []
        self.wrapper_D = {}

        # Carbonaceous atom names
        wrapperAtoms_D = {"ALA": ["CB"],
                          "ARG": ["CB", "CG"],
                          "ASN": ["CB"],
                          "ASP": ["CB"],
                          "CYS": ["CB"],
                          "GLN": ["CB", "CG"],
                          "GLU": ["CB", "CG"],
                          "GLY": [],
                          "HIS": ["CB"],
                          "ILE": ["CB", "CG1", "CG2", "CD1"],
                          "LEU": ["CB", "CG", "CD1", "CD2"],
                          "LYS": ["CB", "CG", "CD"],
                          "MET": ["CB", "CG", "CE"],
                          "PHE": ["CB", "CG", "CD1", "CD2", "CE1", "CE2", "CZ"],
                          "PRO": ["CB", "CG"],
                          "SER": [],
                          "THR": ["CG2"],
                          "TRP": ["CB", "CG", "CD2", "CE3", "CZ2", "CZ3", "CH2"],
                          "TYR": ["CB", "CG", "CD1", "CD2", "CE1", "CE2"],
                          "VAL": ["CB", "CG1", "CG2"]}

        runCommand("set bg_color white")

        # Build atom list for all carbonaceous atoms:
        carbonaceousAtoms_L = []
        for r in prot.residues:
            if r.type in wrapperAtoms_D.keys():
                for atom in r.atoms:
                    if atom.name in wrapperAtoms_D[r.type]:
                        carbonaceousAtoms_L.append(atom)
                        
        shell = Shell(carbonaceousAtoms_L, 0.0, self.sphere_Radius)

        backBoneDonors_L = []
        for r in prot.residues:
            if r.type in wrapperAtoms_D.keys():
                if r.findAtom("N"):
                    backBoneDonors_L.append(r.findAtom("N"))

        # Select the backbone of the specified model:
        runCommand("select #" + str(prot.id)+ " & backbone.full")
        runCommand("findhbond selRestrict both lineWidth " + str(self.line_width) +
                   " color gray distSlop %4.1f" % self.dist_Slop + " angleSlop %4.1f" % self.angle_Slop)
        runCommand("~sel")

        hBondsForSpecifiedDonors_L = FindHBond.findHBonds([prot], donors = backBoneDonors_L,
                                                          distSlop = self.dist_Slop, angleSlop = self.angle_Slop)
        for pair in hBondsForSpecifiedDonors_L:
            donor = pair[0]
            acptr = pair[1]

            # We work with backbone acceptors within standard residues:
            if not(acptr.residue.type in wrapperAtoms_D.keys()): continue
            if acptr.name != "O": continue
            
            self.hBonds_L.append(pair)
            if self.alpha_Centers:
                donorNbrs_S = Set(shell.getAtomsInShell(donor.residue.findAtom("CA")))
                acptrNbrs_S = Set(shell.getAtomsInShell(acptr.residue.findAtom("CA")))
            else:
                donorNbrs_S = Set(shell.getAtomsInShell(donor.residue.findAtom("N")))
                acptrNbrs_S = Set(shell.getAtomsInShell(acptr.residue.findAtom("O")))
            allNbrs_S = donorNbrs_S.union(acptrNbrs_S)
            self.wrapper_D[(donor, acptr)] = allNbrs_S
            nbrCount = len(allNbrs_S)
            if nbrCount <= self.wrap_Threshold:
                self.dehydrons_L.append((donor, acptr))
                




