import numpy as np
import chimera
from numpy import *

#==============================================================================
# Inertial Axes CLASS
#==============================================================================
# This class can be used to generate an object that holds the set of mutually
# orthogonal inertial axes.  The input is a list of atoms. The eigen decomposition
# will produce a list of inertial axes (held in self.inertialAxes_L) and the
# the primary axis will be self.inertialAxes_L[0].
# This class will only define the primary axis as a mathematical construct (it does
# not create any visual component for the display).

class InertialAxes(object):
    def __init__(self, atoms_L, massWeighted = False):
        self.atoms_L = atoms_L
        self.centroid = self.centroid(massWeighted = massWeighted)
        self.inertialAxes_L = []    # List of vectors that are the inertial axes.
        self.primaryAxis = None     # The primary axis will be self.inertialAxes_L[0].
    
        tensorMat = np.zeros((3,3))
        if massWeighted:
            for atom in self.atoms_L:
                tensorMat += atom.element.mass * self.__tensorMatOneAtom(np.array(atom.coord())
                                                                         - self.centroid)
        else:
            for atom in self.atoms_L:
                tensorMat += self.__tensorMatOneAtom(np.array(atom.coord()) - self.centroid)

        # With the tensor matrix now computed, we extract the eigenvector
        # corresponding to the smallest eigenvalues:
        eigvals, eigvecs = linalg.eig(tensorMat)
        ind = eigvals.argsort()  # Sort the eigenvalues to get the needed eigenvectors.
                                      # Be careful here to extract eigenvectors
                                      # from the transpose of eigvecs!
        for i in range(3):
            self.inertialAxes_L.append(eigvecs.transpose()[ind[i]])

        # The next four variables are the most often used qunatities related to the primary axis:
        self.primaryAxis = self.inertialAxes_L[0]
        (self.startPoint, self.endPoint) = self.min_maxProjection(0)
        self.length = np.linalg.norm(self.endPoint - self.startPoint)
        


    # -----------------------------------------------------------------------------
    # Function to compute the centroid of the atoms in the list.
    def centroid(self, massWeighted = False):
        weightSum = 0.0
        sum = zeros(3, float)
        if massWeighted:
            for a in self.atoms_L:
                weightSum += a.element.mass
                sum += np.array(a.coord())*a.element.mass
            return sum/weightSum
        else:
            for a in self.atoms_L:
                sum += a.coord()
            return sum/float(len(self.atoms_L))


    # -----------------------------------------------------------------------------
    # This computes the contribution made by one atom to the tensor matrix.
    # The return value is a matrix that will be added to other matrices corresponding to other atoms.
    # The 3D coordinates of the atom are provided by coordArray.
    # This routine relies on the observation that this contribution is equal to:
    # the identity matrix multiplied by the norm squared of the coordinates
    # minus the outer product of the coordinate vector with itself.
    # This routine assumes that coordArray holds the coordinates of the atom relative to the centroid.
    # Note: array([coordArray]) is a 1 by 3 array.
    def __tensorMatOneAtom(self, coordArray):        
        sumSquares = sum(coordArray*coordArray)
        return sumSquares * np.identity(3) - array([coordArray])*array([coordArray]).transpose()


    # -----------------------------------------------------------------------------
    # Given an atom object this function gets the coordinates of the atom and projects
    # these coordinates onto the primary axis.  It returns the coordinates of this projection.
    # The coordinates are given relative to the frame of reference established by the PDB file.
    def projectionOnAxis(self, atom):
        atmCoords = np.array(atom.coord()) - self.centroid   # Compute atom coords relative to centroid
        return sum(self.primaryAxis * atmCoords) * self.primaryAxis + self.centroid
        # The centroid was added to convert back to the PDB frame of reference.


    # -----------------------------------------------------------------------------
    # Given an atom object this function computes the perpendicular distance
    # from the atom to the primary axis.
    def distanceToAxis(self, atom):
        atmCoords = np.array(atom.coord())
        return np.linalg.norm(atmCoords - self.projectionOnAxis(atom))
        

    # -----------------------------------------------------------------------------
    # Given an index that selects an axis (0, 1, or 2 where 0 corresponds to the primary
    # axis) this function will project all atoms in the atoms_L list onto that axis.
    # It computes the dot products of this axis and with all the vectors going from the
    # centroid to atoms in the atom list atoms_L.  
    # It then returns a 2-tuple holding the minimum dot product and the maximum dot product.
    def min_maxProjection(self, i):
        atmCoords = [np.array(atom.coord()) - self.centroid   for atom in self.atoms_L]
        dotProds = [sum(self.inertialAxes_L[i] * aC)  for aC in atmCoords]
        return (min(dotProds), max(dotProds))


    # -----------------------------------------------------------------------------
    # Given an index that selects an axis (0, 1, or 2 where 0 corresponds to the primary
    # axis) this function will calculates the length of the shape-weighted axis (as described
    # by Browner, Fauman, and Fletterick in the Biochemistry 1992 Vol.31, 11297-11304 paper).
    def shape_weightedAxisLength(self, i):
        numeratorSum = 0.0
        atomWeightSum = 0.0
        for atom in self.atoms_L:
            dotProd = sum(self.inertialAxes_L[i] * (np.array(atom.coord()) - self.centroid))
            numeratorSum += atom.element.mass * dotProd * dotProd
            atomWeightSum += atom.element.mass
        return np.sqrt(numeratorSum/atomWeightSum)
        










