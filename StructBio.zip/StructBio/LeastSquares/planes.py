import chimera, numpy
from numpy import array, linalg, zeros, dot, arccos


#==============================================================================
# Planes CLASS
#==============================================================================

class Planes(object):
    def __init__(self, c, n):
        # The next two arrays (3-component vectors) are enough to define a plane in the
        # PDB frame of reference.
        self.center = c
        self.normal = n/linalg.norm(n)


    # -----------------------------------------------------------------------------
    # Given an atom object or an array object this function returns the coordinates.
    def getCoords(self, atomORarray):
        if type(atomORarray) is chimera.Atom:  coords = array(atomORarray.coord())
        if type(atomORarray) is numpy.ndarray: coords = atomORarray
        if not(type(atomORarray) is chimera.Atom or type(atomORarray) is numpy.ndarray):
            print "Bad argument type in getCoords function call."
            return None
        return coords

    # -----------------------------------------------------------------------------
    # Given an atom object or an array object this function gets the coordinates (or directly uses
    # the array) to define the coordinates of a point P (coordsP) in the PDB frame of reference.
    # It then projects these coordinates onto the plane by:
    #   1) Subtract the center c array to get the "local" coordinates localP (in a frame of
    #      reference that has c as the origin.
    #   2) Calculate the projection of localP on the normal vector (self.normal).
    #   3) Subtract this result from coordsP to get the projection on the plane relative to the PDB
    #      frame of reference.
    def projectionOnPlane(self, atomORarray):           
        # Compute coordinates relative to an origin at the centroid.
        coordsP = self.getCoords(atomORarray)
        localP = coordsP - self.center  # Step 1
        projOnNormal = self.normal*dot(self.normal, localP) # Step 2
        return coordsP - projOnNormal # Step 3

    # -----------------------------------------------------------------------------
    # Given an atom object or an array object this function computes the perpendicular distance
    # from that point to the least squares plane.
    def distanceToPlane(self, atomORarray):
        return linalg.norm(self.getCoords(atomORarray) - self.projectionOnPlane(atomORarray))
        
    # -----------------------------------------------------------------------------
    # Given two atom objects or array objects this function computes the angle between
    # the line joining these two points and the projection of this line in the LS plane.
    def angleToPlane(self, a_atomORarray, b_atomORarray):
        # Compute the coordinates:
        a_coords = self.getCoords(a_atomORarray)
        b_coords = self.getCoords(b_atomORarray)
        distBTWNcoords = linalg.norm(a_coords - b_coords)
        
        a_coordsProj = self.projectionOnPlane(a_atomORarray)
        b_coordsProj = self.projectionOnPlane(b_atomORarray)
        distBTWNprojections = linalg.norm(a_coordsProj - b_coordsProj)
        
        return arccos(distBTWNprojections/distBTWNcoords)*180/numpy.pi


#==============================================================================
# Least Squares Plane CLASS
#==============================================================================

class LeastSquaresPlane(Planes):
    def __init__(self, atoms_L):
        self.atoms_L = atoms_L
        self.centroid = self.centroid()
        self.localAxes_L = []       # Vectors providing local frame of reference.
        self.normalToPlane = None   # The normal to the plane will be localAxes_L[0].

        coords_L = []               # List of atom coordinates relative to centroid.
        for a in self.atoms_L:
            coords_L.append(array(a.coord()) - self.centroid)

        # Use coords_L to build matrixA:
        matrixA = array(coords_L)
        eigvals, eigvecs = linalg.eig(dot(matrixA.transpose(), matrixA))
        ind = eigvals.argsort() # Sort the eigenvalues to get the needed eigenvector.
        # Be careful here.  We have to extract eigenvectors from the transpose of eigvecs!
        # We consider the first eigenvector to be the normal to the plane and
        # (in the coordinate system set up at centroid), it will be the z-axis.
        # The other two eigenvectors will be passed back to give us the unit vectors
        # defining the x-axis and y-axis.  They are kept in self.localAxes_L (just in case
        # they are needed for some other application).
        for i in range(3):
            self.localAxes_L.append(eigvecs.transpose()[ind[i]])
        self.normalToPlane = self.localAxes_L[0]

        Planes.__init__(self, self.centroid, self.normalToPlane)

        


    # -----------------------------------------------------------------------------
    # Function to compute the centroid of the atoms in the list.
    def centroid(self):
        sum = zeros(3, float)
        for a in self.atoms_L:
            sum += a.coord()
        return sum/float(len(self.atoms_L))
