"""
The ChainsFetcherBase class can only be used as a base class.  
The derived class should have a method that will create a fourth frame in the
dialog.  Typical usage:

import Tkinter as tk
from StructBio.ModelessDialogs.chainsFetcherBase import ChainsFetcherBase

#===============================================================================
# YourDerivedDialog class
#===============================================================================
class YourDerivedDialog(ChainsFetcherBase): 
    def __init__(self, title = ""):
        ChainsFetcherBase.__init__(self, title = title)
        # Do not change the left side of this assignment.
        self.functionForNextFrame = self.yourFrameBuilder  
    
    #-------------------------------------------------------------------------
    def yourFrameBuilder(self):
        # This is your function that will build more frames in the dialog.
        # Use the grid method for placement in the dialog and start at row 3 of the parent.
        # The parent dialog can be accessed via self.getParent().
        
        # Sample frame:
        self.yourNewFrame = tk.LabelFrame(self.getParent(), bd = 2, text = " Your frame title ", relief = tk.RIDGE)
        self.yourNewFrame.grid(row = 3, column = 0, padx = 4, pady = 4, sticky = tk.W)
        
        < Code to put widgets into the frame and to define the callback functions. >
        # In this code the dialog widgets can be placed using a grid that is relative to self.yourNewFrame.

        < More code that deals with the protein >
        # The final protein with selected submodel and selected chains within
        # that submodel can be accessed via self.getProt().
        
#===============================================================================
# Mainline:
#===============================================================================

aDialog = YourDerivedDialog(title = "Your window title")

"""

import chimera
from chimera import runCommand, selection

# GUI imports:
import Tkinter as tk
from chimera.baseDialog import ModelessDialog

#===============================================================================
# ChainsFetcherBase class
#===============================================================================
class ChainsFetcherBase(ModelessDialog):
    
    buttons = ("Close")
    help = False    # Leave this out to get a Help button.

    #===========================================================================
    # fetchProt_frame
    
    def fillInUI(self, parent, title = " "):
        # Start with a clean display:
        chimera.closeSession()
        
        self.parent = parent
        
        self.selectedChainIDs_L = []
        self.modelID = (0,0) # This default value may change if the file is an NMR file.

        fetchProt_frame = tk.LabelFrame(parent, bd = 2, relief = tk.RIDGE, text = " Fetch PDB file ")
        fetchProt_frame.grid(row = 0, column = 0, padx = 4, pady = 4, sticky = tk.W)
        
        # Get info specifying protein file:
        tk.Label(fetchProt_frame, text =  " PDB ID: ").grid(row = 0, column = 0, pady = 4, sticky = tk.W)
        self.pdb_ID_entryVar = tk.StringVar()
        self.eP = tk.Entry(fetchProt_frame, textvariable = self.pdb_ID_entryVar, width = 7, bg = "white")
        self.eP.grid(row = 0, column = 1, padx = 4, pady = 4, sticky = tk.E)

        self.btnFetch = tk.Button(fetchProt_frame, text = " Fetch ", command = self.btnFetch_Func)
        self.btnFetch.grid(row = 0, column = 2, padx = 4, pady = 4)

        self.eP.bind('<Return>', self.btnFetch_Func)

    #-------------------------------------------------------------------------
    # Callback functions for fetchProt_frame
    
    def btnFetch_Func(self, e = None):
        if len(chimera.openModels.listIds()) > 0: return
        if len(self.pdb_ID_entryVar.get()) != 4: return
        self.eP.config(state = tk.DISABLED)
        self.btnFetch.config(state = tk.DISABLED)
        
        # Fetch the protein and eliminate anything outside of the specified chain.
        self.prot_L = chimera.openModels.open(self.pdb_ID_entryVar.get(), type="PDB")

        if len(self.prot_L) > 1:
            self.buildSubModelsFrame()
        else:
            # If we get this far then there are no submodels and we have a single protein.
    
            # Determine which chains to keep for further processing:
            self.prot = self.prot_L[0]
            self.getChains()

            

    #===========================================================================
    # subModel_frame for selecting a submodel
    
    def buildSubModelsFrame(self):
        subModel_frame = tk.LabelFrame(self.parent, bd = 2,relief = tk.RIDGE, text = " Choose submodel ")
        subModel_frame.grid(row = 1, column = 0, columnspan = 3, padx = 4, pady = 4, sticky = tk.W + tk.E)

        rBtns_frame = tk.Frame(subModel_frame, bd = 2,relief = tk.RIDGE)
        rBtns_frame.grid(row = 0, column = 0, padx = 4, pady = 4, sticky = tk.W + tk.E)

        modelIDs_L = chimera.openModels.listIds() # A list of 2-tuples each like (prot.id, subid)
        self.rBtnResult = tk.IntVar()
        self.rBtnResult.set(str(modelIDs_L[0][1])) # This button starts off selected.
        runCommand("sel #0." + str(modelIDs_L[0][1]))
        self.rBs_L = []
        for ix in range(len(modelIDs_L)):
            modelID = modelIDs_L[ix][1]
            rB = tk.Radiobutton(rBtns_frame, text = "%2d" % modelID, variable = self.rBtnResult,
                                value = modelID, command = self.rBtn_Func)
            rB.grid(row = ix/10, column = ix%10, padx = 4, pady = 4, sticky = tk.W)
            self.rBs_L.append(rB)

        self.rBtnAccept = tk.Button(subModel_frame, text = " Accept ", command = self.rBtnAccept_Func)
        self.rBtnAccept.grid(row = 1, column = 0, padx = 4, pady = 4, sticky = tk.E)

        
    #-------------------------------------------------------------------------
    # Callback functions for subModel_frame

    def rBtn_Func(self):
        runCommand("sel #0." + str(self.rBtnResult.get()))


    def rBtnAccept_Func(self):
        # Get a molecule in selection (which might have been done using the mouse).
        molSel_L = selection.currentMolecules()
        if len(molSel_L) == 0:
            self.rBtnResult.set(None)
            return
        # If the mouse was used to select multiple models we simply take the first one.
        molSel = molSel_L[0]  

        # Set radio button corresponding to subid
        self.rBtnResult.set(molSel.subid)

        # Prohibit any further selection via radio buttons and the accept button.
        self.rBtnAccept.config(state = tk.DISABLED)
        for rB in self.rBs_L:
            rB.config(state = tk.DISABLED)

        for p in self.prot_L:
            if p.subid != molSel.subid: continue
            self.prot = p
        
        # Kill off all nonselected submodels.
        runCommand("sel #0; ~sel #0." + str(molSel.subid) + "; delete sel; ~sel")

        # Determine which chains to keep for further processing:
        self.getChains()

    #===========================================================================
    # getChains_frame for selecting chains.  No frame is built if there is only one chain.
    
    def getChains(self):
        chains_L = self.prot.sequences(asDict = True).keys()
        chains_L.sort()
        if len(chains_L) == 1:
            self.selectedChainIDs_L.append(chains_L[0])
            self.functionForNextFrame()
        else:

            selChains_frame = tk.LabelFrame(self.parent, bd = 2,relief = tk.RIDGE, text = " Select chains ")
            selChains_frame.grid(row = 2, column = 0, columnspan = 3, padx = 4, pady = 4, sticky = tk.W + tk.E)
            
            chkB_frame = tk.Frame(selChains_frame, bd = 2, relief = tk.RIDGE)
            chkB_frame.grid(row = 0, column = 0, padx = 4, pady = 4, sticky = tk.W + tk.E)

            self.cbB_L = []
            self.checkBoxVars_D = {}
            for ix in range(len(chains_L)):
                self.checkBoxVars_D[chains_L[ix]] = tk.IntVar()
                cbB = tk.Checkbutton(chkB_frame, text = chains_L[ix],
                                     variable = self.checkBoxVars_D[chains_L[ix]], command = self.chkB_Func)
                cbB.grid(row = ix/10, column = ix%10, padx = 4, pady = 4, sticky = tk.E)
                self.cbB_L.append(cbB)

            self.btnChAccpt = tk.Button(selChains_frame, text = " Accept ", command = self.btnChainAccept_Func)
            self.btnChAccpt.grid(row = 1, column = 0, padx = 4, pady = 4, sticky = tk.E)

    #-------------------------------------------------------------------------
    # Callback functions for getChains_frame

    def chkB_Func(self):
        command = "sel :"
        for k in self.checkBoxVars_D.keys():
            chkVal = self.checkBoxVars_D[k].get()
            if chkVal: command += "." + k + ","
        command = command.rstrip(",")
        if command == "sel :":
            runCommand("~sel")
        else: runCommand(command)
    
    def btnChainAccept_Func(self):

        # Get chains in selection (which might have been done using the mouse).
        self.selectedChainIDs_L = [seq.chain for seq in selection.currentChains()]
        
        # If the user has cleared the selection, then update checkboxes accordingly:
        if len(self.selectedChainIDs_L) == 0:  
            for k in self.checkBoxVars_D.keys():
                self.checkBoxVars_D[k].set(0)
            return

        # Update checkboxes to reflect any changes made with a mouse:
        for k in self.checkBoxVars_D.keys():
            if k in self.selectedChainIDs_L:
                self.checkBoxVars_D[k].set(1)
            else:
                self.checkBoxVars_D[k].set(0)

        # Disable all buttons related to chain selection:
        self.btnChAccpt.config(state = tk.DISABLED)
        for cb in self.cbB_L:
            cb.config(state = tk.DISABLED)
        
        # Kill off chains not selected:
        commandLine = "sel #" + str(self.prot.id) + ";" 
        for chainID in self.selectedChainIDs_L:
            commandLine += " ~sel #" + str(self.prot.id) + ":." + chainID + ";"
            #commandLine += " ~sel :." + chainID + ";"  ######################################################
        commandLine += " delete sel; ~sel"
        runCommand(commandLine)

        self.functionForNextFrame()

    #-------------------------------------------------------------------------    
    #-------------------------------------------------------------------------
    # Functions for communication with a derived class:

    def getProt(self):
        return self.prot

    def getParent(self):
        return self.parent

    def functionForNextFrame(self):
        pass
        

