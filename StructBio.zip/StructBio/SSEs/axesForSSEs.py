import chimera, numpy
from numpy import *
from StructBio.LeastSquares.inertialAxes import InertialAxes

# This code will generate an axis for those Secondary Structural Elements (helices or strands,
# never loops) as specified by the helices and strands parameters of the class invocation.
# Note that isolation of an SSE is more complicated than simply checking to see if residues
# have isHelix and isStrand attributes set to True.  We have to handle situations in which
# a sequence of residues goes from the end of a chain to the start of the next chain.

#==============================================================================
# AxesForSSEs CLASS
#==============================================================================
class AxesForSSEs(object):
    def __init__(self, protMol, tolerance = 3.5, minLength = 5.0, chainId = "", helices = True, strands = True):
        self.prot = protMol
        self.tolerance = tolerance
        self.minLength = minLength
        self.chainId = chainId
        self.inertialAxes_L = []
        self.sseTypes = []
        if helices: self.sseTypes.append("H")
        if strands: self.sseTypes.append("S")

        self.__withinSSE = False
        
        ssAtoms_L = [] # Temporary list to pass SSE atoms to the recursiveAxes funciton.

        r = self.prot.findResidue(0)
        while r in self.prot.residues:
            if r.findAtom("CA") == None:
                r = self.prot.residueAfter(r)   # Skip nonstandard residues.
                continue
            if self.chainId != "" and r.id.chainId != self.chainId:
                r = self.prot.residueAfter(r)  # Skip residues in chains not specified in arguments.
                continue
            # Look for start of SSE:
            if not self.__startOfSSE(r):
                r = self.prot.residueAfter(r)
                continue
            
            # Found start.  Pull in CA atoms until end of SSE.
            ssAtoms_L.append(r.findAtom("CA"))
            while not self.__endOfSSE(r):
                r = self.prot.residueAfter(r)
                ssAtoms_L.append(r.findAtom("CA"))
                
            self.inertialAxes_L += self.__recursiveAxes(ssAtoms_L)
            ssAtoms_L = []
            r = self.prot.residueAfter(r)

    # -----------------------------------------------------------------------------
    # This function returns a list of objects each being an instance of the class InertialAxes.
    # The input is a list of atom objects.
    # NOTE:  We are assuming that this is an ordered list.  That is, as we move through the list,
    # the projections of the atoms on the axis (to be computed) move along the axis in an ordered fashion.
    # The function computes an axis for the given list of atoms and then checks to make sure that all
    # atoms in the list are within a specified tolerance from the axis.  If there are atoms farther from
    # the axis than the distance specified by the tolerance, then the list is split and the function
    # is called recursively on each of the smaller lists.
    def __recursiveAxes(self, atoms_L):
        
        if len(atoms_L) <= self.minLength: return [] # Do not bother with very short atom lists.

        # Get the inertia axes for this list of atoms:
        axisForAtoms = InertialAxes(atoms_L)

        # Are all atoms within tolerance from the axis?
        maxDist = 0.0
        for ix in range(1, len(atoms_L) - 1):
            dist = axisForAtoms.distanceToAxis(atoms_L[ix])
            if dist > maxDist:
                maxDist = dist

        if maxDist < self.tolerance:
            return [axisForAtoms]
        else:
            maxLoc = len(atoms_L)/2
            lo_atoms_L = []
            hi_atoms_L = []
            for i in range(maxLoc): lo_atoms_L.append(atoms_L[i])
            for i in range(maxLoc, len(atoms_L)): hi_atoms_L.append(atoms_L[i])
            return  self.__recursiveAxes(lo_atoms_L) + self.__recursiveAxes(hi_atoms_L)

    # -----------------------------------------------------------------------------
    # For a given residue, return the secondary structure type as a letter code.
    def __ssType(self, res):
        ssType = "T"                    # Turn
        if res.isHelix:  ssType = "H"   # Helix
        if res.isStrand: ssType = "S"   # Strand
        if res.phi > 0.0: ssType = "T"  # Sudden turn ==> helix breaker
        return ssType

    # -----------------------------------------------------------------------------
    # For a given residue, determine whether it is at the beginning of a SSE.
    def __startOfSSE(self, res):
        # If res has a type that is not in sseTypes then it cannot be at the start
        # of an SSE that is important to us, so we set withinSSE to False and leave.
        if self.__ssType(res) not in self.sseTypes:
            self.__withinSSE = False
            return False
        # If we get this far, then res has a type indicating that it is in an SSE
        # that has been designated to have an axis.
        self.__withinSSE = True
        # Now check to see if it is at the start of a "new SSE".
        prevRes = self.prot.residueBefore(res)
        if prevRes == None: return True # We are at start of the protein.
        # If we get this far then we have a previous residue
        # (but it might be in a different chain or in a different type of SSE).
        if prevRes.id.chainId != res.id.chainId: return True
        if prevRes.type != res.type: return True
        # If we get this far then we are within an SSE but not at the start of an SSE:            
        return False       

    # -----------------------------------------------------------------------------
    # For a given residue, determine whether it is at the snd of a SSE.
    def __endOfSSE(self, res):
        # If not within an SSE we cannot be ending an SSE so just return False.
        if not self.__withinSSE: return False
        # If we get this far, then we are within an SSE.
        nextRes = self.prot.residueAfter(res)
        if nextRes == None: return True  # Res is a final residue with structure data.
        # If we get this far then there is a next residue.
        if nextRes.id.chainId != res.id.chainId: return True    # Res is at end of a chain.
        if self.__ssType(nextRes) != self.__ssType(res): return True # Res is at end of current SSE.
        # If we get this far then we are within an SSE but not at the end of the SSE.
        return False


