import LinearEnergyFunctions
import LJ

