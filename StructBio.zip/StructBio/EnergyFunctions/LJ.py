import chimera, numpy, sets
from numpy import array, linalg
from sets import Set

#==============================================================================
# Lennard Jones evaluation CLASS
#==============================================================================

class LJ_evaluation(object):
    def __init__(self):
        # Map from residue and atom names to Amber Atom Types:
        self.elementNameMap_D = {':ALA@C': 'C',    ':ALA@CA': 'CT',  ':ALA@CB': 'CT',  ':ALA@H': 'H', ':ALA@HA': 'H1',
                                 ':ALA@HB1': 'HC', ':ALA@HB2': 'HC', ':ALA@HB3': 'HC', ':ALA@N': 'N', ':ALA@O': 'O', ':ALA@OXT': 'O',
                                 ':ALA@H1': 'H1', ':ALA@H2': 'H1', ':ALA@H3': 'H1', 

                                 ':ARG@C': 'C', ':ARG@CA': 'CT', ':ARG@CB': 'CT', ':ARG@CD': 'CT', ':ARG@CG': 'CT',
                                 ':ARG@CZ': 'CA', ':ARG@H': 'H', ':ARG@HA': 'H1', ':ARG@HB2': 'HC', ':ARG@HB3': 'HC',
                                 ':ARG@HD2': 'H1', ':ARG@HD3': 'H1', ':ARG@HE': 'H', ':ARG@HG2': 'HC', ':ARG@HG3': 'HC',
                                 ':ARG@HH11': 'H', ':ARG@HH12': 'H', ':ARG@HH21': 'H', ':ARG@HH22': 'H', ':ARG@N': 'N',
                                 ':ARG@NE': 'N2', ':ARG@NH1': 'N2', ':ARG@NH2': 'N2', ':ARG@O': 'O', ':ARG@OXT': 'O',
                                 ':ARG@H1': 'H1', ':ARG@H2': 'H1', ':ARG@H3': 'H1',

                                 ':ASP@C': 'C', ':ASP@CA': 'CT', ':ASP@CB': 'CT', ':ASP@CG': 'C', ':ASP@H': 'H', ':ASP@HA': 'H1',
                                 ':ASP@HB2': 'HC', ':ASP@HB3': 'HC', ':ASP@N': 'N', ':ASP@O': 'O', ':ASP@OD1': 'O2', ':ASP@OD2': 'O2', ':ASP@OXT': 'O',
                                 ':ASP@H1': 'H1', ':ASP@H2': 'H1', ':ASP@H3': 'H1',

                                 ':ASN@C': 'C', ':ASN@CA': 'CT', ':ASN@CB': 'CT', ':ASN@CG': 'C', ':ASN@H': 'H', ':ASN@HA': 'H1',
                                 ':ASN@HB2': 'HC', ':ASN@HB3': 'HC', ':ASN@HD21': 'H', ':ASN@HD22': 'H', ':ASN@N': 'N',
                                 ':ASN@ND2': 'N', ':ASN@O': 'O', ':ASN@OD1': 'O', ':ASN@OXT': 'O', ':ASN@HN1': 'H', ':ASN@HN2': 'H',
                                 ':ASN@H1': 'H1', ':ASN@H2': 'H1', ':ASN@H3': 'H1', ':ASN@HC2': 'HC', ':ASN@HC3': 'HC', ':ASN@HC': 'H1',

                                 ':CYS@C': 'C', ':CYS@CA': 'CT', ':CYS@CB': 'CT', ':CYS@H': 'H', ':CYS@HA': 'H1', ':CYS@HB2': 'HC',
                                 ':CYS@HB3': 'HC', ':CYS@HG': 'HS', ':CYS@N': 'N', ':CYS@O': 'O', ':CYS@SG': 'SH', ':CYS@OXT': 'O',
                                 ':CYS@H1': 'H1', ':CYS@H2': 'H1', ':CYS@H3': 'H1', 

                                 ':GLU@C': 'C', ':GLU@CA': 'CT', ':GLU@CB': 'CT', ':GLU@CD': 'C', ':GLU@CG': 'CT',
                                 ':GLU@H': 'H', ':GLU@HA': 'H1', ':GLU@HB2': 'HC', ':GLU@HB3': 'HC', ':GLU@HG2': 'HC',
                                 ':GLU@HG3': 'HC', ':GLU@N': 'N', ':GLU@O': 'O', ':GLU@OE1': 'O2', ':GLU@OE2': 'O2', ':GLU@OXT': 'O',
                                 ':GLU@H1': 'H1', ':GLU@H2': 'H1', ':GLU@H3': 'H1', 

                                 ':GLN@C': 'C', ':GLN@CA': 'CT', ':GLN@CB': 'CT', ':GLN@CD': 'C', ':GLN@CG': 'CT', ':GLN@H': 'H',
                                 ':GLN@HA': 'H1', ':GLN@HB2': 'HC', ':GLN@HB3': 'HC', ':GLN@HE21': 'H', ':GLN@HE22': 'H', ':GLN@HG2': 'HC',
                                 ':GLN@HG3': 'HC', ':GLN@N': 'N', ':GLN@NE2': 'N', ':GLN@O': 'O', ':GLN@OE1': 'O', ':GLN@OXT': 'O',
                                 ':GLN@H1': 'H1', ':GLN@H2': 'H1', ':GLN@H3': 'H1', 

                                 ':GLY@C': 'C', ':GLY@CA': 'CT', ':GLY@H': 'H', ':GLY@HA2': 'H1', ':GLY@HA3': 'H1',
                                 ':GLY@N': 'N', ':GLY@O': 'O', ':GLY@OXT': 'O',
                                 ':GLY@H1': 'H1', ':GLY@H2': 'H1', ':GLY@H3': 'H1', 

                                 ':HIS@C': 'C', ':HIS@CA': 'CT', ':HIS@CB': 'CT', ':HIS@CD2': 'C', ':HIS@CE1': 'C', ':HIS@CG': 'C',
                                 ':HIS@H': 'H', ':HIS@HA': 'H1', ':HIS@HB2': 'HC', ':HIS@HB3': 'HC', ':HIS@HD2': 'H4', ':HIS@HE1': 'H5',
                                 ':HIS@HE2': 'H', ':HIS@N': 'N', ':HIS@ND1': 'N', ':HIS@NE2': 'N', ':HIS@O': 'O', ':HIS@OXT': 'O',
                                 ':HIS@H1': 'H1', ':HIS@H2': 'H1', ':HIS@H3': 'H1', ':HIS@HD1': 'H',

                                 ':ILE@C': 'C', ':ILE@CA': 'CT', ':ILE@CB': 'CT', ':ILE@CD1': 'CT', ':ILE@CG1': 'CT', ':ILE@CG2': 'CT',
                                 ':ILE@H': 'H', ':ILE@HA': 'H1', ':ILE@HB': 'HC', ':ILE@HD11': 'HC', ':ILE@HD12': 'HC', ':ILE@HD13': 'HC',
                                 ':ILE@HG12': 'HC', ':ILE@HG13': 'HC', ':ILE@HG21': 'HC', ':ILE@HG22': 'HC', ':ILE@HG23': 'HC',
                                 ':ILE@N': 'N', ':ILE@O': 'O', ':ILE@OXT': 'O',
                                 ':ILE@H1': 'H1', ':ILE@H2': 'H1', ':ILE@H3': 'H1', 

                                 ':LEU@C': 'C', ':LEU@CA': 'CT', ':LEU@CB': 'CT', ':LEU@CD1': 'CT', ':LEU@CD2': 'CT', ':LEU@CG': 'CT',
                                 ':LEU@H': 'H', ':LEU@HA': 'H1', ':LEU@HB2': 'HC', ':LEU@HB3': 'HC', ':LEU@HD11': 'HC', ':LEU@HD12': 'HC',
                                 ':LEU@HD13': 'HC', ':LEU@HD21': 'HC', ':LEU@HD22': 'HC', ':LEU@HD23': 'HC', ':LEU@HG': 'HC',
                                 ':LEU@N': 'N', ':LEU@O': 'O', ':LEU@OXT': 'O',
                                 ':LEU@H1': 'H1', ':LEU@H2': 'H1', ':LEU@H3': 'H1', 

                                 ':LYS@C': 'C', ':LYS@CA': 'CT', ':LYS@CB': 'CT', ':LYS@CD': 'CT', ':LYS@CE': 'CT', ':LYS@CG': 'CT',
                                 ':LYS@H': 'H', ':LYS@HA': 'H1', ':LYS@HB2': 'HC', ':LYS@HB3': 'HC', ':LYS@HD2': 'HC', ':LYS@HD3': 'HC',
                                                                                                              ':LYS@HE2': 'HP', ':LYS@HE3': 'HP', ':LYS@HG2': 'HC', ':LYS@HG3': 'HC', ':LYS@HZ1': 'H',
                                 ':LYS@HZ2': 'H', ':LYS@HZ3': 'H', ':LYS@N': 'N', ':LYS@NZ': 'N3', ':LYS@O': 'O', ':LYS@OXT': 'O',
                                 ':LYS@H1': 'H1', ':LYS@H2': 'H1', ':LYS@H3': 'H1', 

                                 ':MET@C': 'C', ':MET@CA': 'CT', ':MET@CB': 'CT', ':MET@CE': 'CT', ':MET@CG': 'CT', ':MET@H': 'H',
                                 ':MET@HA': 'H1', ':MET@HB2': 'HC', ':MET@HB3': 'HC', ':MET@HE1': 'H1', ':MET@HE2': 'H1', ':MET@HE3': 'H1',
                                 ':MET@HG2': 'H1', ':MET@HG3': 'H1', ':MET@N': 'N', ':MET@O': 'O', ':MET@SD': 'S', ':MET@OXT': 'O',
                                 ':MET@H1': 'H1', ':MET@H2': 'H1', ':MET@H3': 'H1', 

                                 ':PHE@C': 'C', ':PHE@CA': 'CT', ':PHE@CB': 'CT', ':PHE@CD1': 'CA', ':PHE@CD2': 'CA', ':PHE@CE1': 'CA',
                                 ':PHE@CE2': 'CA', ':PHE@CG': 'CA', ':PHE@CZ': 'CA', ':PHE@H': 'H', ':PHE@HA': 'H1', ':PHE@HB2': 'HC',
                                 ':PHE@HB3': 'HC', ':PHE@HD1': 'HA', ':PHE@HD2': 'HA', ':PHE@HE1': 'HA', ':PHE@HE2': 'HA',
                                 ':PHE@HZ': 'HA', ':PHE@N': 'N', ':PHE@O': 'O', ':PHE@OXT': 'O',
                                 ':PHE@H1': 'H1', ':PHE@H2': 'H1', ':PHE@H3': 'H1', 

                                 ':PRO@C': 'C', ':PRO@CA': 'CT', ':PRO@CB': 'CT', ':PRO@CD': 'CT', ':PRO@CG': 'CT', ':PRO@HA': 'H1',
                                 ':PRO@HB2': 'HC', ':PRO@HB3': 'HC', ':PRO@HD1': 'H1', ':PRO@HD2': 'H1', ':PRO@HD3': 'H1', ':PRO@HG2': 'HC',
                                 ':PRO@HG3': 'HC', ':PRO@N': 'N', ':PRO@O': 'O', ':PRO@OXT': 'O',
                                 ':PRO@H1': 'H1', ':PRO@H2': 'H1', ':PRO@H3': 'H1', 

                                 ':SER@C': 'C', ':SER@CA': 'CT', ':SER@CB': 'CT', ':SER@H': 'H', ':SER@HN1': 'H', ':SER@HN2': 'H', ':SER@HA': 'H1', ':SER@HB2': 'H1',
                                 ':SER@HB3': 'H1', ':SER@HG': 'HO', ':SER@N': 'N', ':SER@O': 'O', ':SER@OG': 'OH', ':SER@OXT': 'O',
                                 ':SER@H1': 'H1', ':SER@H2': 'H1', ':SER@H3': 'H1', ':SER@HC': 'H1', ':SER@HC2': 'H1', ':SER@HC3': 'H1', ':SER@HO': 'HO',

                                 ':THR@C': 'C', ':THR@CA': 'CT', ':THR@CB': 'CT', ':THR@CG2': 'CT', ':THR@H': 'H', ':THR@HA': 'H1',
                                 ':THR@HB': 'H1', ':THR@HG1': 'HO', ':THR@HG21': 'HC', ':THR@HG22': 'HC', ':THR@HG23': 'HC',
                                 ':THR@N': 'N', ':THR@O': 'O', ':THR@OG1': 'OH', ':THR@OXT': 'O',
                                 ':THR@H1': 'H1', ':THR@H2': 'H1', ':THR@H3': 'H1', 

                                 ':TRP@C': 'C', ':TRP@CA': 'CT', ':TRP@CB': 'CT', ':TRP@CD1': 'C', ':TRP@CD2': 'C', ':TRP@CE2': 'C',
                                 ':TRP@CE3': 'CA', ':TRP@CG': 'C', ':TRP@CH2': 'CA', ':TRP@CZ2': 'CA', ':TRP@CZ3': 'CA', ':TRP@H': 'H',
                                 ':TRP@HA': 'H1', ':TRP@HB2': 'HC', ':TRP@HB3': 'HC', ':TRP@HD1': 'H4', ':TRP@HE1': 'H', ':TRP@HE3': 'HA',
                                 ':TRP@HH2': 'HA', ':TRP@HZ2': 'HA', ':TRP@HZ3': 'HA', ':TRP@N': 'N', ':TRP@NE1': 'N', ':TRP@O': 'O', ':TRP@OXT': 'O',
                                 ':TRP@H1': 'H1', ':TRP@H2': 'H1', ':TRP@H3': 'H1', 

                                 ':TYR@C': 'C', ':TYR@CA': 'CT', ':TYR@CB': 'CT', ':TYR@CD1': 'CA', ':TYR@CD2': 'CA', ':TYR@CE1': 'CA',
                                 ':TYR@CE2': 'CA', ':TYR@CG': 'CA', ':TYR@CZ': 'C', ':TYR@H': 'H', ':TYR@HA': 'H1', ':TYR@HB2': 'HC',
                                 ':TYR@HB3': 'HC', ':TYR@HD1': 'HA', ':TYR@HD2': 'HA', ':TYR@HE1': 'HA', ':TYR@HE2': 'HA',
                                 ':TYR@HH': 'HO', ':TYR@N': 'N', ':TYR@O': 'O', ':TYR@OH': 'OH', ':TYR@OXT': 'O',
                                 ':TYR@H1': 'H1', ':TYR@H2': 'H1', ':TYR@H3': 'H1', 

                                 ':VAL@C': 'C', ':VAL@CA': 'CT', ':VAL@CB': 'CT', ':VAL@CG1': 'CT', ':VAL@CG2': 'CT', ':VAL@H': 'H',
                                 ':VAL@HA': 'H1', ':VAL@HB': 'HC', ':VAL@HG11': 'HC', ':VAL@HG12': 'HC', ':VAL@HG13': 'HC', ':VAL@HG21': 'HC',
                                 ':VAL@HG22': 'HC', ':VAL@HG23': 'HC', ':VAL@N': 'N', ':VAL@O': 'O', ':VAL@OXT': 'O',
                                 ':VAL@H1': 'H1', ':VAL@H2': 'H1', ':VAL@H3': 'H1'}

        
        self.radiusMap_D = {'H': 0.6000, 'HO': 0.0000, 'HS': 0.6000, 'HC': 1.4870, 'H1': 1.3870, 'H2': 1.2870, 'H3': 1.1870, 'HP': 1.1000,
                            'HA': 1.4590, 'H4': 1.4090, 'H5': 1.3590, 'HW': 0.0000, 'HZ': 1.487262,
                            'O': 1.6612, 'O2': 1.6612, 'OH': 1.7210, 'OS': 1.6837, 'OW': 1.778541, 'OZ': 1.778541,
                            'CT': 1.9080, 'CA': 1.9080, 'CM': 1.9080, 'C': 1.9080, 'CZ': 1.908185,
                            'N': 1.8240, 'N2': 1.8240, 'N3': 1.875,
                            'S': 2.0000, 'SH': 2.0000,
                            'P': 2.1000}

        self.epsMap_D = {'H': 0.0157, 'HO': 0.0000, 'HS': 0.0157, 'HC': 0.0157, 'H1': 0.0157, 'H2': 0.0157, 'H3': 0.0157, 'HP': 0.0157,
                         'HA': 0.0150, 'H4': 0.0150, 'H5': 0.0150, 'HW': 0.0000, 'HZ': 0.0157,
                         'O': 0.2100, 'O2': 0.2100, 'OH': 0.2104, 'OS': 0.1700, 'OW': 0.1553, 'OZ': 0.1553,
                         'CT': 0.1094, 'CA': 0.0860, 'CM': 0.0860, 'C': 0.0860, 'CZ': 0.1094,
                         'N': 0.1700, 'N2': 0.1700, 'N3': 0.1700,
                         'S': 0.2500, 'SH': 0.2500,
                         'P': 0.2000}

        self.maxExtensionMap_D = {'CYS': 3.06, 'ASP': 3.01, 'SER': 3.14, 'GLN': 4.55, 'LYS': 5.79, 'ILE': 3.44,
                                  'PRO': 3.32, 'THR': 3.24, 'PHE': 5.39, 'ASN': 3.37, 'MET': 5.01, 'HIS': 4.62,
                                  'LEU': 3.44, 'ARG': 6.96, 'TRP': 6.39, 'VAL': 2.98, 'GLU': 3.64, 'TYR': 6.06,
                                  'GLY': 0.00, 'ALA': 0.00}

        
        
        # Precompute a_ij and b_ij values:
        self.a_ij_D = {}
        self.b_ij_D = {}
        for aStr in self.epsMap_D.keys():
            for bStr in self.epsMap_D.keys():
                aRadius = self.radiusMap_D[aStr]
                if aStr[0] == 'H': aRadius = self.radiusMap_D[aStr]/2.0
                bRadius = self.radiusMap_D[bStr]
                if bStr[0] == 'H': bRadius = self.radiusMap_D[bStr]/2.0
                # The radii of hydrogens was reduced by 50% because of their uncertain position.
                # See page 64 of Kingsford's thesis.
                r_ijStar = aRadius + bRadius
                r_ijStar_2 = r_ijStar * r_ijStar
                r_ijStar_6 = r_ijStar_2 * r_ijStar_2 * r_ijStar_2
                r_ijStar_12 = r_ijStar_6 * r_ijStar_6
                eps_ij = numpy.sqrt(self.epsMap_D[aStr] * self.epsMap_D[bStr])
                self.a_ij_D[aStr + "#" + bStr] = eps_ij * r_ijStar_12
                self.b_ij_D[aStr + "#" + bStr] = 2.0 * eps_ij * r_ijStar_6


    def bondCount(self, a, b):
        oneBondAway_S = Set(a.neighbors)
        if b in oneBondAway_S: return 1
        twoBondsAway_S = Set()
        for aNbr in oneBondAway_S:
            twoBondsAway_S.union_update(Set(aNbr.neighbors))
        twoBondsAway_S.discard(a)
        if b in twoBondsAway_S: return 2
        threeBondsAway_S = Set()
        for aNbrNbr in twoBondsAway_S:
            threeBondsAway_S.union_update(Set(aNbrNbr.neighbors))
        if b in threeBondsAway_S: return 3
        return 4    # This value actually means 4 or more bonds.
        

    def atomPairEnergy(self, a, b):
        dist = linalg.norm(array(a.coord()) - array(b.coord()))
        if dist > 10.0: return 0.0  # Return 0 if interatomic distance > 10. (see Kingsford thesis).
        d_2 = dist * dist
        d_6 = d_2 * d_2 * d_2
        d_12 = d_6 * d_6
        aStr = self.elementNameMap_D[':' + a.residue.type + '@' + a.name]
        bStr = self.elementNameMap_D[':' + b.residue.type + '@' + b.name]
        pairEnergy = self.a_ij_D[aStr + "#" + bStr]/d_12 - self.b_ij_D[aStr + "#" + bStr]/d_6
        if abs(pairEnergy) < 0.000001: pairEnergy = 0.0
        if abs(a.residue.id.position - b.residue.id.position) > 1: return pairEnergy
        bC = self.bondCount(a,b)
        #print a.residue.type, a.residue.id.position, a.name, b.residue.type, b.residue.id.position, b.name, bC, pairEnergy  ################################33
        if bC <= 2: return 0.0
        if bC == 3: return min(pairEnergy/2.0, 100.0)  # Max allowed energy is 100 kcal/mol (see Kingsford thesis).
        return min(pairEnergy, 100.0)



    def residuePairEnergy(self, aRes, bRes):
        # This calculates the energy between two residues taking into account the side chain atoms only
        # Backbone atoms NOT included.
        aResBcarbon = aRes.findAtom('CB')
        if aRes.type == 'GLY': aResBcarbon = aRes.findAtom('CA')
        bResBcarbon = bRes.findAtom('CB')
        if bRes.type == 'GLY': bResBcarbon = bRes.findAtom('CA')
        bC_dist = linalg.norm(array(aResBcarbon.coord()) - array(bResBcarbon.coord()))
        if bC_dist > 8.0 + self.maxExtensionMap_D[aRes.type] + self.maxExtensionMap_D[bRes.type]: return 0.0
        
        energy = 0.0
        for a in aRes.atoms:
            if a.name in ('N', 'CA', 'C', 'O', 'HA', 'H', 'HA2', 'HA3', 'H1', 'H2', 'H3'): continue
            for b in bRes.atoms:
                if b.name in ('N', 'CA', 'C', 'O', 'HA', 'H', 'HA2', 'HA3', 'H1', 'H2', 'H3'): continue
                energy += self.atomPairEnergy(a, b)
        return energy

    def residueIntrinsicEnergy(self, aRes, statisticalEnergy, nearbyRes_L, fixedRes_L):
        # This calculates the sum of all atom pair energies such that one atom of a pair is in aRes (side chain only)
        # and the other atom of a pair is a backbone atom in a residue of the nearbyRes_L
        # OR the other atom is in a sidechain of a residue in the fixedRes_L.
        # It is to be expected that fixedRes_L is a subset of the nearbyRes_L
        # Typically, the fixed residues will be nearby and will be GLY, ALA or CYS (cysteine considered a fixed
        # residue if it is involved with a disulfide bridge to another CYS residue).
        energy = statisticalEnergy # This is the energy due to interactions between atoms within this sidechain.
        for a in aRes.atoms:
            if a.name in ('N', 'CA', 'C', 'O', 'HA', 'H', 'HA2', 'HA3', 'H1', 'H2', 'H3'): continue # Skip backbone atoms of aRes.

            # Other atom is in the backbone of residues in nearbyRes_L:
            for nrbyR in nearbyRes_L:
                if abs(nrbyR.id.position - aRes.id.position) <= 1: continue # Skip nearby backbone (see pg. 32 of Kingsford thesis).
                for b in nrbyR.atoms:
                    if b.name in ('N', 'CA', 'C', 'O', 'HA', 'H', 'HA2', 'HA3', 'H1', 'H2', 'H3'):
                        energy += self.atomPairEnergy(a, b)
                        
            # Other atom is in the sidechain of residues in fixedRes_L:
            for fixedR in fixedRes_L:
                for b in fixedR.atoms:
                    if b.name in ('N', 'CA', 'C', 'O', 'HA', 'H', 'HA2', 'HA3', 'H1', 'H2', 'H3'): continue
                    energy += self.atomPairEnergy(a, b)

        return energy
            
