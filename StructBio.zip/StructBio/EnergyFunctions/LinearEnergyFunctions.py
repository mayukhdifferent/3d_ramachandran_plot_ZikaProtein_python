# Functions to compute the energy interaction between two atoms and two residues.
# This is the most trivial version (basically a collision detection).
#
import chimera, numpy, sets
from numpy import linalg, array
from sets import Set


radius_D = {"C": 1.6, "O": 1.3, "N": 1.3, "S": 1.7}
#------------------------------------------------------------------------------
def atomPairEnergy(atom1, atom2):
    # Return 0.0 if atoms are bonded (example: S-S bridge)
    if atom1 in atom2.neighbors: return 0.0
    # Return 0.0 if atoms have a geminal relationship (2 bond separation).
    if Set(atom1.neighbors).intersection(Set(atom2.neighbors)): return 0.0
    distance = linalg.norm(array(atom1.coord()) - array(atom2.coord()))
    r1 = radius_D[atom1.name[0]]
    r2 = radius_D[atom2.name[0]]
    ratio = distance/(r1 + r2)
    if ratio > 1.0: return 0.0
    if ratio < 0.8254: return 10.0
    return 57.2737686*(1.0 - ratio)    # 10/(1-.8254) = 57.2737686

#------------------------------------------------------------------------------
def residuePairEnergy(r1, r2):
    e = 0.0
    for a1 in r1.atoms:
        if a1.name in ("CB", "CA", "N", "O", "C"): continue
        for a2 in r2.atoms:
            e += atomPairEnergy(a1, a2)
    #if e > 0.0: print e  # Used in testing...
    return e

