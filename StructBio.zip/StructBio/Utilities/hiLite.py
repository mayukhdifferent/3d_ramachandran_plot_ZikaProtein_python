import chimera
from chimera import runCommand


#==============================================================================
# HiLiter CLASS
#==============================================================================

class HiLiter(object):
    def __init__(self, p, bgColor = "black"):
        self.prot = p
        self.currentPrimaries_L = []
        self.currentSecondaries_L = []
        self.verbose = False

        # Clear prot display of all ribbons and use wire representation.
        runCommand('set bg_color ' + bgColor)
        runCommand('~ribbon')
        runCommand('sel #0')
        runCommand('display sel')
        runCommand('represent wire sel')
        runCommand('linewidth 2')
        runCommand('~sel')

    # -----------------------------------------------------------------------------
    def idStr(self, a):
        # Build identification string for atom a.
        return str(a.residue.id.position) + "." + a.residue.id.chainId + "@" + a.name
                  
    # -----------------------------------------------------------------------------
    def emphasize(self, primary_L, secondary_L, primOut = "Primary list: ", secnOut = "Secondary list: "):
        if self.verbose:
            print "\n" + primOut
            for a in primary_L:
                print a.residue.type + " " + self.idStr(a)
            print "\n" + secnOut
            for a in secondary_L:
                print a.residue.type + " " + self.idStr(a)
            
        # Bring atoms in current lists back to wire representation:
        for a in self.currentPrimaries_L:
            runCommand("represent wire #0:" + self.idStr(a))
        for a in self.currentSecondaries_L:
            runCommand("represent wire #0:" + self.idStr(a))
            
        self.currentPrimaries_L = primary_L
        self.currentSecondaries_L = secondary_L
        
        for a in self.currentPrimaries_L:
            runCommand("represent bs #0:" + self.idStr(a))
        for a in self.currentSecondaries_L:
            runCommand("represent stick #0:" + self.idStr(a))

    # -----------------------------------------------------------------------------
    def clearEmphasis(self):
        # Bring atoms in current lists back to wire representation:
        for a in self.currentPrimaries_L:
            runCommand("represent wire #0:" + self.idStr(a))
        for a in self.currentSecondaries_L:
            runCommand("represent wire #0:" + self.idStr(a))
            
        self.currentPrimaries_L = []
        self.currentSecondaries_L = []

    # -----------------------------------------------------------------------------
    def setVerbose(self, booleanVal):
        self.verbose = booleanVal
            

