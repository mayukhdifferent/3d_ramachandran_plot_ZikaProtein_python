import chimera, numpy, struct
from chimera import runCommand
from numpy import array

colors_D = {'tan': 'd2b48c', 'sienna': 'a0522d', 'brown': 'a52a2a', 'dark red': '8b0000',
            'firebrick': 'b22222', 'salmon': 'fa8072', 'red': 'ff0000', 'coral': 'ff7f50',
            'sandy brown': 'f4a460', 'orange red': 'ff4500', 'orange': 'ff7f00',
            'goldenrod': 'daa520', 'gold': 'ffd700', 'yellow': 'ffff00', 'khaki': 'f0e68c',
            'dark khaki': 'bdb76b', 'dark olive green': '556b2f', 'olive drab': '6b8e23',
            'chartreuse': '7fff00', 'green': '00ff00', 'dark green': '006400',
            'forest green': '228b22', 'lime green': '32cd32', 'light green': '90ee90',
            'sea green': '2e8b57', 'spring green': '00ff7f', 'dark cyan': '008b8b',
            'light sea green': '20b2aa', 'turquoise': '40e0d0', 'aquamarine': '7fffd4',
            'cyan': '00ffff', 'deep sky blue': '00bfff', 'dodger blue': '1e90ff',
            'steel blue': '4682b4', 'sky blue': '87ceeb', 'light blue': 'add8e6',
            'blue': '0000ff', 'medium blue': '3232cd', 'cornflower blue': '6495ed',
            'navy blue': '000080', 'dark slate blue': '483d8b', 'medium purple': '9370db',
            'purple': 'a020f0', 'plum': 'dda0dd', 'orchid': 'da70d6', 'magenta': 'ff00ff',
            'dark magenta': '8b008b', 'violet red': 'd02090', 'hot pink': 'ff69b4',
            'pink': 'ffc0cb', 'deep pink': 'ff1493', 'rosy brown': 'bc8f8f',
            'slate gray': '708090', 'dark slate gray': '2f4f4f', 'white': 'ffffff',
            'light gray': 'd3d3d3', 'gray': 'bebebe', 'dark gray': 'a9a9a9',
            'dim gray': '696969', 'black': '000000'}


shapely_D = {"ALA": array((200,200,200))/255.,
             "ARG": array(( 20, 90,255))/255.,
             "ASN": array((  0,220,220))/255.,
             "ASP": array((230, 10, 10))/255.,
             "CYS": array((230,230,  0))/255.,
             "GLN": array((  0,220,220))/255.,
             "GLU": array((230, 10, 10))/255.,
             "GLY": array((235,235,235))/255.,
             "HIS": array((130,130,210))/255.,
             "ILE": array(( 15,130, 15))/255.,
             "LEU": array(( 15,130, 15))/255.,
             "LYS": array(( 20, 90,255))/255.,
             "MET": array((230,230,  0))/255.,
             "PHE": array(( 50, 50,170))/255.,
             "PRO": array((220,150,130))/255.,
             "SER": array((250,150,  0))/255.,
             "THR": array((250,150,  0))/255.,
             "TRP": array((180, 90,180))/255.,
             "TYR": array(( 50, 50,170))/255.,
             "VAL": array(( 15,130, 15))/255.}

fletterick_D = {"ALA": array((140,255,140))/255.,
                "ARG": array((  0,  0,124))/255.,
                "ASN": array((255,124,112))/255.,
                "ASP": array((160,  0, 66))/255.,
                "CYS": array((255,255,112))/255.,
                "GLN": array((255, 76, 76))/255.,
                "GLU": array((102,  0,  0))/255.,
                "GLY": array((255,255,255))/255.,
                "HIS": array((112,112,255))/255.,
                "ILE": array((  0, 76,  0))/255.,
                "LEU": array(( 69, 94, 69))/255.,
                "LYS": array(( 71, 71,184))/255.,
                "MET": array((184,160, 66))/255.,
                "PHE": array(( 83, 76, 66))/255.,
                "PRO": array(( 82, 82, 82))/255.,
                "SER": array((255,112, 66))/255.,
                "THR": array((184, 76,  0))/255.,
                "TRP": array(( 79, 70,  0))/255.,
                "TYR": array((140,112, 76))/255.,
                "VAL": array((255,140,255))/255.}
        
def colorByName(color):
    return tuple(array(struct.unpack('BBB', colors_D[color].decode('hex')))/255.)

#------------------------------------------------------------------------------
# Get color based on residue hydrophobicity
def residueKDhColor(res): 
    white = array((1.0, 1.0, 1.0))              # (255, 255, 255)
    dodgerBlue = array((0.118, 0.565, 1.0 ))    # ( 30, 144, 255)
    orangeRed = array((1.0, 0.271, 0.0))        # (255, 69, 0)

    if res.kdHydrophobicity == None: return tuple(white)    
    if res.kdHydrophobicity < 0.0:
        return tuple(white + (white - dodgerBlue)*res.kdHydrophobicity/4.5)
    else:
        return tuple(white + (orangeRed - white)*res.kdHydrophobicity/4.5)

#------------------------------------------------------------------------------
# Get residue color based on Shapely codes
def residueShapelyColor(res):
    if res.type in shapely_D.keys():
        return tuple(shapely_D[res.type])
    else:
        return tuple((0.0, 0.0, 0.0))

#------------------------------------------------------------------------------
# Get residue color based on Fletterick codes
def residueFletterickColor(res):
    if res.type in fletterick_D.keys():
        return tuple(fletterick_D[res.type])
    else:
        return tuple((0.0, 0.0, 0.0))

# -----------------------------------------------------------------------------
def userSpecificationOfChains(k = 2):
    # This routine interacts with the user to get the PDB IDs of k proteins.
    # If a protein has more than one chain there is a further interaction
    # that asks for the specification of a chain.
    # The return value is a list of Chimera protein objects (each a specified chain).
    ret_L = []
    if k == 0: print "To stop requests for more input simply key Enter."
    i = 0
    pdbIDchars = raw_input("Type in a 4 character PDB ID or PDB file name: \n")
    commandLine = "sel #;"
    while pdbIDchars != "":
        prot = chimera.openModels.open(pdbIDchars, type="PDB")[0]
        ret_L.append(prot)
        chains_L = prot.sequences(asDict = True).keys()
        if len(chains_L) == 1: chainForProt = chains_L[0]
        else:
            cStr = ""
            for e in chains_L: cStr += " " + e
            chainForProt = ""
            while chainForProt not in chains_L:
                print "Available chains are: " + cStr
                chainForProt = raw_input("Type in a character to select one of these chains: \n")
        commandLine += " ~sel #" + str(prot.id) + ":." + chainForProt + ";"
        i += 1
        if i == k: break
        pdbIDchars = raw_input("Type in a 4 character PDB ID or PDB file name: \n")

    commandLine += " delete sel; ~sel"
    runCommand(commandLine)
    runCommand("focus")

    return ret_L


# -----------------------------------------------------------------------------

import numpy as np

# Function to provide a list of tick values:
def tickList(minVal, maxVal, numTicks):
    numTicks = max(numTicks, 2) # numTicks should be at least 2.
    incr = (maxVal - minVal)/numTicks
    incrRounded = round(incr, -int(np.floor(np.log10(incr))))
    
    # The first tick is equal to minVal and is rounded with the same precision as incr.
    # If this rounding causes firstTick to be more than the minVal, then we decrease
    # firstTick by an amount equal to the rounded version of incr.
    firstTick = round(minVal, -int(np.floor(np.log10(incr))))
    if firstTick > minVal:
        firstTick = round(minVal - incrRounded, -int(np.floor(np.log10(incr))))

    t_L = []
    nextTick = firstTick
    while nextTick < maxVal + incrRounded:
        if abs(nextTick) < incr * 0.00001:
            nextTick = 0.0 # Zero if sufficiently close to 0.0
        t_L.append(nextTick)
        nextTick += incrRounded       

    # We now have the correct tick values but the internal representation may introduce
    # trailing 9's or a result that is just slightly too large.
    # So, we use formatting to do "final roundup".

    # Calculate number of digits in a large number.
    sig = int(np.ceil(np.log10(max(abs(minVal), abs(maxVal))))) 
    frmt = '%.3g'
    # Display 3 significant digits, but if a number is larger than 999 display them all.
    if sig > 3: frmt = '%.' + str(sig) +'g'
    t_L = ['%s' % float(frmt % x) for x in t_L]
    # Back to floats:
    t_L = [float(c) for c in t_L]

    return t_L

#------------------------------------------------------------------------------
# Function to generate atom identifier string.
def atomIdString(a):
    ar = a.residue
    return ar.type + " " + str(ar.id.position) + "." + ar.id.chainId + " " + a.name
