from StructBio.Scenographics.solids import Solids

import numpy
from numpy import array, linalg

import sets, heapq
from sets import Set

# TERMINOLOGY:
# The base (or parent) classes are used to implement abstract graphs involving
# vertices and the arcs that connect these vertices. Various graph theoretic
# methods are available to perform algorithms such as shortest path and
# extraction of various subgraphs.

# The derived classes are used to provide a visible display representation of
# a graph along with an underlying abstract graph.  When referring to entities
# in the visible graph we make descriptions of methods and attributes
# more clear by using terminology such as "nodes" (instead of vertices)
# and "edges" (instead of arcs).

#==============================================================================
# BASE CLASSES
#==============================================================================
#------------------------------------------------------------------------------
# Vertex Base Class
#------------------------------------------------------------------------------

class Vertex(object):
    def __init__(self, vertexWeight = 0.0):
        self.vertexWeight = vertexWeight    # Floating point vertex weight.


#------------------------------------------------------------------------------
# Arc Base Class
#------------------------------------------------------------------------------

class Arc(object):
    def __init__(self, arcWeight = 0.0):
        self.arcWeight = arcWeight    # Floating point arc weight.
        
#------------------------------------------------------------------------------
# GraphBase CLASS
#------------------------------------------------------------------------------
# The vertexLabel will be used by the application to reference the vertex
# object.  It should be a character string that is easily created and
# has some meaning within the application.  For example, a vertex that
# is representing a residue in a protein might be labelled as ":3.A" if
# has id.position 3 in chain A.

class GraphBase(object):
    def __init__(self):
    
        # Dictionary mapping vertex labels to vertex objects.
        #   Key: a vertex label.
        #   Value corresponding to key: a vertex object
        self.vertices_D = {}

        # Dictionary of dictionaries mapping vertex label pairs to arc objects.
        #   First key: a label for one of the 2 vertices that have an arc between them.
        #   Value corrsponding to first key: a dictionary with keys that are labels
        #       of vertices that are neighbors of the vertex spcified by the first key.
        #       Second key: the label of the other vertex defining the arc.
        #       Value corresponding to second key: an arc object.
        self.arcs_D = {}

        self._visited_D = {}    # Node visited status for connected components function.
        self.orderedPathLabels_L = []   # Only defined if the graph was constructed as a shortest path.

    def addVertex(self, vertexLabel, vertex):
        self.vertices_D[vertexLabel] = vertex
        self.arcs_D[vertexLabel] = {}

    def addArc(self, vertexAlabel, vertexBlabel, arc):
        self.arcs_D[vertexAlabel][vertexBlabel] = arc
        self.arcs_D[vertexBlabel][vertexAlabel] = arc

    def getArcTupleList(self):
        # Returns a list of tuples each containing the two vettex labels of an arc.
        retVal = []
        for vA in self.arcs_D.keys():
            for vB in self.arcs_D[vA].keys():
                retVal.append((vA, vB))
        return retVal

    def getSubgraph_VertexWeightsWithinRange(self, minVal, maxVal):
        subGraphBase = GraphBase()
        for vrtxLabel in self.vertices_D.keys():
            if (self.vertices_D[vrtxLabel].vertexWeight < minVal or
                self.vertices_D[vrtxLabel].vertexWeight > maxVal): continue
            subGraphBase.addVertex(vrtxLabel, self.vertices_D[vrtxLabel])
        for vrtxLabel in subGraphBase.vertices_D.keys():
            for nbrLabel in self.arcs_D[vrtxLabel].keys():
                if nbrLabel in subGraphBase.vertices_D.keys():
                    subGraphBase.addArc(vrtxLabel, nbrLabel, self.arcs_D[vrtxLabel][nbrLabel])
        return subGraphBase

    def getSubgraph_VertexDegreeWithinRange(self, minVal, maxVal):
        subGraphBase = GraphBase()
        for vrtxLabel in self.arcs_D.keys():
            if (len(self.arcs_D[vrtxLabel]) < minVal or
                len(self.arcs_D[vrtxLabel]) > maxVal): continue
            subGraphBase.addVertex(vrtxLabel, self.vertices_D[vrtxLabel])
        for vrtxLabel in subGraphBase.vertices_D.keys():
            for nbrLabel in self.arcs_D[vrtxLabel].keys():
                if nbrLabel in subGraphBase.vertices_D.keys():
                    subGraphBase.addArc(vrtxLabel, nbrLabel, self.arcs_D[vrtxLabel][nbrLabel])
        return subGraphBase

    def getSubgraph_ArcsRemoved(self, arcTuples_L):
        # Input is a list of tuples each containing the two vertex labels of arcs that
        # will not be in the generated subgraph.
        subGraphBase = GraphBase()
        for vrtxLabel in self.vertices_D.keys():
            subGraphBase.addVertex(vrtxLabel, self.vertices_D[vrtxLabel])
        for vrtxLabel in self.arcs_D.keys():
            for nbrLabel in self.arcs_D[vrtxLabel].keys():
                if (vrtxLabel, nbrLabel) in arcTuples_L: continue
                subGraphBase.addArc(vrtxLabel, nbrLabel, self.arcs_D[vrtxLabel][nbrLabel])
        return subGraphBase

    
    def getShortestPath(self, startingVertexLabel, endingVertexLabel):
        # Use Dijkstra's algorithm to find shortest path from starting vertex to ending vertex.
        # Shortest means that the cost (the sum of all the weights of the arcs forming the
        # path) will be minimized.
        cloud = Set()
        closestVertexInCloud = {}   # Used for backtracking from ending node to starting node.
                                    # Maps a vertex label to the vertex label of the closest
                                    # vertex in the cloud.
        # Build priority queue:
        priorityQueue = []
        entries_D = {}  # This will allow us to update the entries in the heap.
                        # It maps a vertex label to an entry in the priority queue.
        for vrtxLabel in self.vertices_D.keys():
            heapEntry = [float('inf'), vrtxLabel] # All cost values start at infinity.
            entries_D[vrtxLabel] = heapEntry
            heapq.heappush(priorityQueue, heapEntry)        

        # The next statement essentially sets cost at starting node to be 0.0.
        entries_D[startingVertexLabel][0] = 0.0
        
        heapq.heapify(priorityQueue)
        closestVertexInCloud[startingVertexLabel] = ""

        while len(priorityQueue) > 0:
            v = heapq.heappop(priorityQueue)
            cloud.add(v[1]) # v[1] is the label of the vertex just entering the cloud.
            # Now do the relaxation:
            for nbrVrtxLabel in self.arcs_D[v[1]].keys():
                if nbrVrtxLabel in cloud: continue
                cost_via_v = v[0] + self.arcs_D[nbrVrtxLabel][v[1]].arcWeight
                if cost_via_v < entries_D[nbrVrtxLabel][0]:
                    entries_D[nbrVrtxLabel][0] = cost_via_v
                    closestVertexInCloud[nbrVrtxLabel] = v[1]
            heapq.heapify(priorityQueue)

        # Now do backtracking to get path from ending node to starting node:
        # The path will be extracted as a subgraph.
        subGraphBase = GraphBase()
        if not endingVertexLabel in closestVertexInCloud.keys():
            print "End node not accessible from start node."
            return subGraphBase
        subGraphBase.addVertex(endingVertexLabel, self.vertices_D[endingVertexLabel])
        subGraphBase.orderedPathLabels_L.append(endingVertexLabel)
        prevVrtxLabel = endingVertexLabel
        nextVrtxLabel = closestVertexInCloud[endingVertexLabel]
        while nextVrtxLabel != "":
            subGraphBase.orderedPathLabels_L.append(nextVrtxLabel)
            subGraphBase.addVertex(nextVrtxLabel, self.vertices_D[nextVrtxLabel])
            subGraphBase.addArc(prevVrtxLabel, nextVrtxLabel,
                                self.arcs_D[prevVrtxLabel][nextVrtxLabel])
            prevVrtxLabel = nextVrtxLabel
            nextVrtxLabel = closestVertexInCloud[nextVrtxLabel]
        subGraphBase.orderedPathLabels_L.reverse()
        return subGraphBase

    def computeConnectedComponents(self, minSize):
        retVal = []
        # Build dictionary that tracks nodes visited.
        for vLab in self.vertices_D.keys():
            self._visited_D[vLab] = False

        for vrtxLabel in self.vertices_D.keys():
            if self._visited_D[vrtxLabel]: continue
            newSubGraphBase = GraphBase()
            self._dfs(vrtxLabel, newSubGraphBase)

            # Now generate arcs:
            for vrtxLabel in newSubGraphBase.vertices_D.keys():
                for nbrLabel in self.arcs_D[vrtxLabel].keys():
                    if vrtxLabel <= nbrLabel: continue
                    newSubGraphBase.addArc(vrtxLabel, nbrLabel, self.arcs_D[vrtxLabel][nbrLabel])

            if len(newSubGraphBase.vertices_D) >= minSize:
                retVal.append(newSubGraphBase)

        return retVal

    def _dfs(self, vLabel, newSGB):
        self._visited_D[vLabel] = True
        currentNode = self.vertices_D[vLabel]
        newSGB.addVertex(vLabel, currentNode)
        for nbrVrtxLabel in self.arcs_D[vLabel].keys():
            if not self._visited_D[nbrVrtxLabel]:
                self._dfs(nbrVrtxLabel, newSGB)
                

#==============================================================================
# DERIVED CLASSES
#==============================================================================
#------------------------------------------------------------------------------
# Node CLASS
#------------------------------------------------------------------------------        
class Node(Vertex):
    def __init__(self, nodeWeight, coords, radius, color):
        Vertex.__init__(self, nodeWeight)
        self.coords = coords
        self.radius = radius
        self.color = color

#------------------------------------------------------------------------------
# Edge CLASS
#------------------------------------------------------------------------------        
class Edge(Arc):
    def __init__(self, edgeWeight, radius, color):
        Arc.__init__(self, edgeWeight)
        self.radius = radius
        self.color = color

#------------------------------------------------------------------------------
# Graph CLASS
#------------------------------------------------------------------------------        
class Graph(GraphBase):
    def __init__(self, graphName = "Graph"):
        GraphBase.__init__(self)
        self.graphName = graphName
        self.solids = Solids(self.graphName)

    def addNode(self, nodeLabel, node):
        GraphBase.addVertex(self, nodeLabel, node) #Note: graphBase is dealing with node objects.
        self.solids.addSphere(node.coords, node.radius, node.color)

    def addEdge(self, nodeAlabel, nodeBlabel, edge):
        GraphBase.addArc(self, nodeAlabel, nodeBlabel, edge)
        self.solids.addSpindle(self.vertices_D[nodeAlabel].coords,
                               self.vertices_D[nodeBlabel].coords, edge.radius, edge.color)
 
    def getSubgraph_NodeWeightsWithinRange(self, minVal, maxVal, graphName = "SubGraph"):
        subGraphBase = self.getSubgraph_VertexWeightsWithinRange(minVal, maxVal)
        return self._buildSubGraphFromSubGraphBase(subGraphBase, graphName)
 
    def getSubgraph_NodeDegreeWithinRange(self, minVal, maxVal, graphName = "SubGraph"):
        subGraphBase = self.getSubgraph_VertexDegreeWithinRange(minVal, maxVal)
        return self._buildSubGraphFromSubGraphBase(subGraphBase, graphName)

    def getSubgraph_EdgesRemoved(self, edgeTuples_L, graphName = "SubGraph"):
        subGraphBase = self.getSubgraph_ArcsRemoved(edgeTuples_L)
        return self._buildSubGraphFromSubGraphBase(subGraphBase, graphName)        
    
    def getShortestPathSubgraph(self, startingNodeLabel, endingNodeLabel, graphName = "Shortest Path"):
        pathInGraphBase = self.getShortestPath(startingNodeLabel, endingNodeLabel)
        return self._buildSubGraphFromSubGraphBase(pathInGraphBase, graphName)

    def getConnectedComponents(self, minSize, graphName = "Connected Component"):
        connected_components_L = []
        componentsInGraphBase_L = self.computeConnectedComponents(minSize)
        ix = 0
        for c in componentsInGraphBase_L:
            connected_components_L.append(self._buildSubGraphFromSubGraphBase(c, graphName + " " + str(ix)))
            ix += 1
        return connected_components_L
            

    def _buildSubGraphFromSubGraphBase(self, subGraph_Base, graphName):
        subGraph = Graph(graphName)
        subGraph.vertices_D = subGraph_Base.vertices_D
        subGraph.arcs_D = subGraph_Base.arcs_D
        subGraph.orderedPathLabels_L = subGraph_Base.orderedPathLabels_L
        del subGraph_Base
            
        for ndLb in subGraph.vertices_D.keys():
            subGraph.solids.addSphere(subGraph.vertices_D[ndLb].coords,
                                      subGraph.vertices_D[ndLb].radius,
                                      subGraph.vertices_D[ndLb].color)
        for vrtxAlabel in subGraph.arcs_D.keys():
            for vrtxBlabel in subGraph.arcs_D[vrtxAlabel].keys():
                if vrtxAlabel >= vrtxBlabel: continue # Only one spindle for bidirectional edge.
                subGraph.solids.addSpindle(self.vertices_D[vrtxAlabel].coords,
                                           self.vertices_D[vrtxBlabel].coords,
                                           subGraph.arcs_D[vrtxAlabel][vrtxBlabel].radius,
                                           subGraph.arcs_D[vrtxAlabel][vrtxBlabel].color)
        return subGraph
    

    def buildDelaunayTessellation(self, edgeLengthThreshold):
        nodeLabels_L = self.vertices_D.keys()
        coordsData_L = []
        for ndLab in nodeLabels_L:
            coordsData_L.append(self.vertices_D[ndLab].coords)
            
        tetrahedrons = computeTetrahedrals(coordsData_L)
        
        edgeSet = Set()
        for tetra in tetrahedrons:
            tetra.sort()
            tetraOK = True
            for i in range(4):
                for j in range(i+1, 4):
                    diffVector = array(coordsData_L[tetra[i]]) - array(coordsData_L[tetra[j]])
                    if linalg.norm(diffVector) > edgeLengthThreshold: tetraOK = False
            if tetraOK:
                for i in range(4):
                    for j in range(i+1, 4):
                        edgeSet.add((tetra[i], tetra[j]))
        for edge in edgeSet:
            length = linalg.norm(array(coordsData_L[edge[0]]) - array(coordsData_L[edge[1]]))
            s_color = tuple((array(self.vertices_D[nodeLabels_L[edge[0]]].color) +
                             array(self.vertices_D[nodeLabels_L[edge[1]]].color))/2.0)
            # Note: we are setting edge weight equal to edge length.
            tessEdge = Edge(length, 0.3, s_color)
            self.addEdge(nodeLabels_L[edge[0]], nodeLabels_L[edge[1]], tessEdge)


#==============================================================================
# Functions
#==============================================================================
            
# Compute Delaunay Tetrahedralization
import subprocess
import string
from string import split, strip, join

def computeTetrahedrals(data):
    from CGLutil.findExecutable import findExecutable
    qdelaunay_exe = findExecutable("qdelaunay")
    if qdelaunay_exe == None:
        qdelaunay_exe = "qdelaunay"

    p = subprocess.Popen([qdelaunay_exe, "QJ", "i"],
                         stdin=subprocess.PIPE,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
    child_stdin = p.stdin
    child_stdout = p.stdout
    child_stdin.write(str(3) + "\n")
    child_stdin.write(str(len(data)) + "\n")
    
    for point in data:
        child_stdin.write(join(map(str, point)) + "\n")
    child_stdin.close()

    lines = []
    for line in child_stdout:
        lines.append(strip(line))
    #print lines
    child_stdout.close()
    tetrahedra = map(lambda x: map(int, x), map(string.split, lines[1:]))

    return tetrahedra

