import numpy as np

#=========================================================================
class SurfacePlotBundle(object):
    def __init__(self, x_A, y_A, z_A, color = np.array((.5, .5, .5)), transparency = 1.0, surfaceName = "Surface Plot"):
        # The first three parameters are for three arrays each with the same shape.
        # The entries defined by x_A[i,j], y_A[i,j], and z_A[i,j] define a 3D point p(i,j) = (x, y, z)
        # where x = x_A[i,j], y = y_A[i,j] and z = z_A[i,j].
        # The colors and transparency parameters have default values as shown.
        # If the default values are not used here are the rules:
        # color:
        #       The variable color can be a shape 3 array (this color applied to the entire surface) OR
        #       it can be an array with shape (m, n, 3) where z_A.shape is (m, n).
        #       The entry color[i,j,:] defines the rgb surface color at point p(i,j).
        # transparency:
        #       The variable transparency can be a simple float in the interval [0.0, 1.0] OR
        #       it can be an array with the same shape as z_A.
        
        # Connectivity issues: the surface will be constructed by using addPolygon in the Solids class.
        # Typical polygon has 4 points: p(i, j), p(i, j+1), p(i+1, j+1) and p(i+1, j).

        self.x_A = x_A
        self.y_A = y_A
        self.z_A = z_A
        self.colors_A = None
        self.color = None
        self.transparency_A = None
        self.transparency = None
        self.surfaceName = surfaceName
        
        (self.m, self.n) = z_A.shape
        if x_A.shape != z_A.shape:
            print "Shape of z array not compatible with shape of x array.  Bundle not created"
            return
        if y_A.shape != z_A.shape:
            print "Shape of z array not compatible with shape of y array.  Bundle not created"
            return

        if color.shape != (3,):
            testShape = list(z_A.shape)
            testShape.append(3L)
            if color.shape != tuple(testShape):
                print "Shape of color array must be (m, n, 3) if shape of z array is (m, n).  Bundle not created"
                return
            else: self.colors_A = color
        else: self.color = color
            
        if type(transparency) != float:
            if transparency.shape != z_A.shape:
                print "Shape of z array not compatible with shape of t array.  Bundle not created"
                return
            else: self.transparency_A = transparency
        else: self.transparency = transparency

        self.xMin = min(map(min, self.x_A))
        self.xMax = max(map(max, self.x_A))
        self.yMin = min(map(min, self.y_A))
        self.yMax = max(map(max, self.y_A))
        self.zMin = min(map(min, self.z_A))
        self.zMax = max(map(max, self.z_A))
        
        self.showInPlot = False # Used when a plot bundle is to be ignored.
