import chimera, numpy as np

from StructBio.Plots.surfacePlotBundle import SurfacePlotBundle
from StructBio.Scenographics.solids import Solids
from StructBio.Scenographics.surfaces import Surfaces
from StructBio.Scenographics.labels import LabelGroups
from StructBio.Utilities.miscFunctions import tickList

#=========================================================================
class TickLists(object):
    def __init__(self, surfacePlotBundles_L, numTicks):
        self.xMin = min(pB.xMin for pB in surfacePlotBundles_L)
        self.xMax = max(pB.xMax for pB in surfacePlotBundles_L)
        self.yMin = min(pB.yMin for pB in surfacePlotBundles_L)
        self.yMax = max(pB.yMax for pB in surfacePlotBundles_L)
        self.zMin = min(pB.zMin for pB in surfacePlotBundles_L)
        self.zMax = max(pB.zMax for pB in surfacePlotBundles_L)
        self.xDiff = self.xMax - self.xMin
        self.yDiff = self.yMax - self.yMin
        self.zDiff = self.zMax - self.zMin
        self.numTicks = numTicks # Number of ticks for longest dimension.

        # Initial tick lists:
        self.longestSide = max(self.xDiff, self.yDiff, self.zDiff)
        self.num_xTicks = int(self.numTicks*(self.xDiff)/self.longestSide)
        self.num_yTicks = int(self.numTicks*(self.yDiff)/self.longestSide)
        self.num_zTicks = int(self.numTicks*(self.zDiff)/self.longestSide)

        self.updateTickLists()

    def updateTickLists(self):
        self.xTicks_L = tickList(self.xMin, self.xMax, self.num_xTicks)
        self.yTicks_L = tickList(self.yMin, self.yMax, self.num_yTicks)
        self.zTicks_L = tickList(self.zMin, self.zMax, self.num_zTicks)

#=========================================================================
class SurfacePlot(Surfaces):
    def __init__(self, spbObj, spbColoration = True, lowestZcolor = (0., 0., 1.), highestZcolor = (1., 0., 0.)):
        Surfaces.__init__(self, modelName = spbObj.surfaceName)

        # Note: lowestZcolor is the color associated with the lowest z value of the plot frame.
        # This lowest Z value is not necessarily the zMin value for the spbObj.

        self.spbObj = spbObj
        self.lowestZcolor = np.array(lowestZcolor)
        self.highestZcolor = np.array(highestZcolor)
                 
        m = self.spbObj.m
        n = self.spbObj.n
        
        self.x_A = self.spbObj.x_A
        self.y_A = self.spbObj.y_A
        self.z_A = self.spbObj.z_A
        self.colors_A = np.zeros((m, n, 3), float)
        self.transparency_A = np.ones((m, n), float)

        if spbColoration:
            # If we get this far we assume that one of self.spbObj.color or self.spbObj.colors)A is not None.
            if self.spbObj.color:
                for u in range(m):
                    for v in range(n):
                        self.colors_A[u, v, :] = self.spbObj.color                  
            else: self.colors_A = self.spbObj.colors_A
            if self.spbObj.transparency:
                for u in range(m):
                    for v in range(n):
                        self.transparency_A[u, v] = self.spbObj.transparency
            else: self.transparency_A = self.spbObj.transparency_A
        else:
            zRange = self.spbObj.zMax - self.spbObj.zMin
            colorRange = self.highestZcolor - self.lowestZcolor
            for u in range(m):
                for v in range(n):
                    self.colors_A[u, v, :] = self.lowestZcolor + colorRange*(self.z_A[u, v] - self.spbObj.zMin)/zRange

        # Generate first version of "current slice" of the surface as a list of points:
        curSlice_L = []
        curColors_L = []
        curTransparency_L = []
        for v in range(n):
            curSlice_L.append((self.x_A[0, v], self.y_A[0, v], self.z_A[0, v]))
            curColors_L.append(self.colors_A[0, v, :])
            curTransparency_L.append(self.transparency_A[0, v])

        for u in range(1, m):
            # Generate next slice:
            nxtSlice_L = []
            nxtColors_L = []
            nxtTransparency_L = []
            for v in range(n):
                nxtSlice_L.append((self.x_A[u, v], self.y_A[u, v], self.z_A[u, v]))
                nxtColors_L.append(self.colors_A[u, v, :])
                nxtTransparency_L.append(self.transparency_A[u,v])
            # Display the polygons:
            for kx in range(n - 1):
                # Calculate color of poygon as average of colors on the vertices.
                c = (curColors_L[kx] + curColors_L[kx+1] + nxtColors_L[kx+1] + nxtColors_L[kx])/4.0
                t = (curTransparency_L[kx] + curTransparency_L[kx+1] + nxtTransparency_L[kx+1] + nxtTransparency_L[kx])/4.0
                self.addPolygon([np.array(curSlice_L[kx]), np.array(curSlice_L[kx+1]),
                                    np.array(nxtSlice_L[kx+1]), np.array(nxtSlice_L[kx])],
                                    c, transparency = t)
            curSlice_L = nxtSlice_L
            curColors_L = nxtColors_L
            curTransparency_L = nxtTransparency_L
            
                                                            
#=========================================================================
class Axes(Solids):
    def __init__(self, ticks,
                 xAxisColor = (.8, 0., 0.),
                 yAxisColor = (0., .8, 0.),
                 zAxisColor = (0., 0., .8)):
        Solids.__init__(self, modelName = "Axes")
        
        # Get all min and max values from the tick lists:
        xMin = ticks.xTicks_L[0]; xMax = ticks.xTicks_L[-1]
        yMin = ticks.yTicks_L[0]; yMax = ticks.yTicks_L[-1]
        zMin = ticks.zTicks_L[0]; zMax = ticks.zTicks_L[-1]
        
        # Calculate arrow radius in proportion to plot size:
        aR = min(ticks.xMax - xMin, yMax - yMin, zMax - zMin)*0.01
        
        self.addArrow(np.array((xMin, yMin, zMin)),
                      np.array((xMax + 2.*aR, yMin, zMin)), aR, xAxisColor)
        self.addArrow(np.array((xMin, yMin, zMin)),
                      np.array((xMin, yMax + 2.*aR, zMin)), aR, yAxisColor)
        self.addArrow(np.array((xMin, yMin, zMin)),
                      np.array((xMin, yMin, zMax + 2.*aR)), aR, zAxisColor)

#=========================================================================
class QuadrantPlanes(Surfaces):
    def __init__(self, ticks,
                 yzPlaneColor = (.8, 0., 0.),
                 zxPlaneColor = (0., .8, 0.),
                 xyPlaneColor = (0., 0., .8), transparency = 0.2):
        Surfaces.__init__(self, modelName = "Quadrant Planes")
        
        # Get all min and max values from the tick lists:
        xMin = ticks.xTicks_L[0]; xMax = ticks.xTicks_L[-1]
        yMin = ticks.yTicks_L[0]; yMax = ticks.yTicks_L[-1]
        zMin = ticks.zTicks_L[0]; zMax = ticks.zTicks_L[-1]
        
        self.addPolygon([np.array((xMin, yMin, zMin)), np.array((xMin, yMax, zMin)),
                         np.array((xMin, yMax, zMax)), np.array((xMin, yMin, zMax))],
                        yzPlaneColor, transparency = transparency)
        self.addPolygon([np.array((xMin, yMin, zMin)), np.array((xMin, yMin, zMax)),
                         np.array((xMax, yMin, zMax)), np.array((xMax, yMin, zMin))],
                        zxPlaneColor, transparency = transparency)
        self.addPolygon([np.array((xMin, yMin, zMin)), np.array((xMax, yMin, zMin)),
                         np.array((xMax, yMax, zMin)), np.array((xMin, yMax, zMin))],
                        xyPlaneColor, transparency = transparency)
    
#=========================================================================
class GridLines(Solids):
    def __init__(self, ticks):
        Solids.__init__(self, modelName = "Grid Lines")

        # Get all min and max values from the tick lists:
        xMin = ticks.xTicks_L[0]; xMax = ticks.xTicks_L[-1]
        yMin = ticks.yTicks_L[0]; yMax = ticks.yTicks_L[-1]
        zMin = ticks.zTicks_L[0]; zMax = ticks.zTicks_L[-1]
        xDiff = xMax - xMin; yDiff = yMax - yMin; zDiff = zMax - zMin
        numTicks = ticks.numTicks
        
        extra = ticks.longestSide*0.05    # Extension of grid past the quadrant planes.
        gridW = ticks.longestSide*0.002   # Width of gridlines.
        gridC = (0.5, 0.5, 0.5)     # Grid line color (gray).
        
        gridLines = Solids()
        for xt in ticks.xTicks_L:
            self.addBox(np.array((xt, yMin + 0.5*(yDiff + extra), zMin)),
                             (gridW, yDiff + extra, gridW), gridC)
            self.addBox(np.array((xt, yMin, zMin + 0.5*(zDiff + extra))),
                             (gridW, gridW, zDiff + extra), gridC)
        for yt in ticks.yTicks_L:
            self.addBox(np.array((xMin + 0.5*(xDiff + extra), yt, zMin)),
                             (xDiff + extra, gridW, gridW), gridC)
            self.addBox(np.array((xMin, yt, zMin + 0.5*(zDiff + extra))),
                             (gridW, gridW, zDiff + extra), gridC)
        for zt in ticks.zTicks_L:
            self.addBox(np.array((xMin + 0.5*(xDiff + extra), yMin, zt)),
                             (xDiff + extra, gridW, gridW), gridC)
            self.addBox(np.array((xMin, yMin + 0.5*(yDiff + extra), zt)),
                             (gridW, yDiff + extra, gridW), gridC)

#=========================================================================
class TickLabels(LabelGroups):
    def __init__(self, ticks):
        LabelGroups.__init__(self, labelGroupsName = "Labels for Grids & Axes")
        xt_L = ticks.xTicks_L
        yt_L = ticks.yTicks_L
        zt_L = ticks.zTicks_L

        axesExtra = ticks.longestSide * 0.05

        self.addLabelGroup("axesLabels")

        for lab in ("xT_yMax", "xT_zMax", "yT_zMax", "yT_xMax", "zT_xMax", "zT_yMax"):
            self.addLabelGroup(lab)

        for xt in xt_L:
            self.addLabel("xT_yMax", str(xt), (xt, yt_L[-1] + axesExtra, zt_L[0]))
            self.addLabel("xT_zMax", str(xt), (xt, yt_L[0], zt_L[-1] + axesExtra))

        for yt in yt_L:
            self.addLabel("yT_zMax", str(yt), (xt_L[0], yt, zt_L[-1] + axesExtra))
            self.addLabel("yT_xMax", str(yt), (xt_L[-1] + axesExtra, yt, zt_L[0]))

        for zt in zt_L:
            self.addLabel("zT_xMax", str(zt), (xt_L[-1] + axesExtra, yt_L[0], zt))
            self.addLabel("zT_yMax", str(zt), (xt_L[0], yt_L[-1] + axesExtra, zt))

        self.addLabel("axesLabels", "x", (xt_L[-1] + axesExtra, yt_L[0] - axesExtra, zt_L[0] - axesExtra))
        self.addLabel("axesLabels", "y", (xt_L[0] - axesExtra, yt_L[-1] + axesExtra, zt_L[0] - axesExtra))
        self.addLabel("axesLabels", "z", (xt_L[0] - axesExtra, yt_L[0] - axesExtra, zt_L[-1] + axesExtra))           

        self.showLabels()
        
            
#===============================================================================
# Utility functions:


#-------------------------------------------------------------------------------
def plotMultipleSurfaces(spb_L, tickList, spbColoration = True, lowZendColor = (0., 0., 1.0),
                                                     highZendColor = (1.0, 0., 0.)):
    lowZendColor = np.array(lowZendColor)
    highZendColor = np.array(highZendColor)
    fullColorRange = highZendColor - lowZendColor # Full z axis color range.
    fullZRange = tickList.zMax - tickList.zMin
    
    # Plot multiple surfaces and return the TickLists object for them.
    surfacePlots_L = []
    for spb in spb_L:
        lowRangeColor = lowZendColor + fullColorRange*(spb.zMin - tickList.zMin)/fullZRange
        highRangeColor = lowZendColor + fullColorRange*(spb.zMax - tickList.zMin)/fullZRange
        surfPlt = SurfacePlot(spb, spbColoration = spbColoration,
                              lowestZcolor = lowRangeColor, highestZcolor = highRangeColor)
        surfPlt.display()
        surfacePlots_L.append(surfPlt)
    return surfacePlots_L

#-------------------------------------------------------------------------------
def fetchSPB():
    import Tkinter as tk, tkFileDialog, pickle

    fileName = tkFileDialog.askopenfilename(filetypes =  [('Binary Pickle', '*.pkl')],
                                            defaultextension = 'pkl',
                                            title = "Open a surface plot bundle file")

    if len(fileName) > 0:
        with open(fileName, "rb") as input_file:
            pickledSPB = pickle.load(input_file)
        return pickledSPB


