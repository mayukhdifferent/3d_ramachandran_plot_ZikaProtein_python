import chimera, numpy, sets
from chimera import runCommand
from numpy import linalg
from sets import Set

from StructBio.Utilities.shellNeighbors import Shell
from StructBio.StructureOverlap.overlapper import Overlapper
from StructBio.SSEs.axesForSSEs import AxesForSSEs

#==============================================================================
# InertialAxisAlignment CLASS
#==============================================================================

class InertialAxisAlignment(object):
    def __init__(self, protP, protQ, matchThreshold = 5.0, atomDistThreshold = 3.0,
                 inertialAxisTolerance = 3.5, axisMinLength = 3,
                 printingClosestPairs = False, printProgressiveQ = False):
        self.protP = protP
        self.protQ = protQ
        self.matchThreshold = matchThreshold
        self.atomDistThreshold = atomDistThreshold
        self.inertialAxisTolerance = inertialAxisTolerance
        self.axisMinLength = axisMinLength
        self.printingClosestPairs = printingClosestPairs
        self.printProgressiveQ = printProgressiveQ
        # matchThreshold:   this puts an upper bound on the amount of difference between SSE
        #                   related measurements for P and the corresponding measurements in Q.
        #                   Keep default at 5.0
        # atomDistThreshold: This value determines the shell size when looking for close by
        #                   between the CA atoms in P and the CA atoms in Q.
        axesP = AxesForSSEs(self.protP, tolerance = self.inertialAxisTolerance, minLength = self.axisMinLength)
        axesQ = AxesForSSEs(self.protQ, tolerance = self.inertialAxisTolerance, minLength = self.axisMinLength)
        surrogatesP_L = axesP.inertialAxes_L
        surrogatesQ_L = axesQ.inertialAxes_L
        
        overlapper = Overlapper(self.protP)
        bestP_L = []; bestQ_L = []; bestPairCount = 0; bestQval = 0.0
        for ix in range(len(surrogatesP_L)):
            surAP = surrogatesP_L[ix]
            for jx in range(ix + 1, len(surrogatesP_L)):
                surBP = surrogatesP_L[jx]
                begbegDistP = numpy.linalg.norm(surBP.startPoint - surAP.startPoint)
                endendDistP = numpy.linalg.norm(surBP.endPoint - surAP.endPoint)
                surAPssType = ssType(surAP.atoms_L[0].residue)
                surBPssType = ssType(surBP.atoms_L[0].residue)
                for surAQ in surrogatesQ_L:
                    for surBQ in surrogatesQ_L:
                        surAQssType = ssType(surAQ.atoms_L[0].residue)
                        surBQssType = ssType(surBQ.atoms_L[0].residue)
                        if surBQ == surAQ: continue
                        if surAPssType != surAQssType: continue
                        if surBPssType != surBQssType: continue
                        begbegDistQ = numpy.linalg.norm(surBQ.startPoint - surAQ.startPoint)
                        endendDistQ = numpy.linalg.norm(surBQ.endPoint - surAQ.endPoint)

                        # Check all four distance matches:
                        if abs(surAP.length - surAQ.length) > self.matchThreshold: continue
                        if abs(surBP.length - surBQ.length) > self.matchThreshold: continue
                        if abs(begbegDistP - begbegDistQ) > self.matchThreshold: continue
                        if abs(endendDistP - endendDistQ) > self.matchThreshold: continue

                        # Assemble atom lists making sure that the number of atoms coming from
                        # surAP is same as from surAQ and that the number of atoms coming from
                        # surBP is same as from surBQ:
                        atomsForP_L = []; atomsForQ_L = []
                        for i in range(min(len(surAP.atoms_L), len(surAQ.atoms_L))):
                            atomsForP_L.append(surAP.atoms_L[i])
                            atomsForQ_L.append(surAQ.atoms_L[i])
                        for i in range(min(len(surBP.atoms_L), len(surBQ.atoms_L))):
                            atomsForP_L.append(surBP.atoms_L[i])
                            atomsForQ_L.append(surBQ.atoms_L[i])

                        if len(atomsForP_L) == 0 or len(atomsForQ_L) == 0: print "No matches found for SSEs."

                        #raw_input("Press Enter to see next overlap.")
                        overlapper.undoMove()
                        overlapper.moveToOverlap(zip(atomsForP_L, atomsForQ_L))
                        closePairs_L = self.getListOfClosePairs(self.atomDistThreshold)
                        closePairCount = len(closePairs_L)
                        qVal = self.getQualityValue(closePairs_L)
                        if qVal > bestQval:
                        #if closePairCount > bestPairCount:
                            bestP_L = atomsForP_L
                            bestQ_L = atomsForQ_L
                            bestPairCount = closePairCount
                            bestQval = qVal


        # Go back to best overlap:
        pairings_L = zip(bestP_L, bestQ_L)
        overlapper.moveToOverlap(pairings_L)

        allPairings_L = self.getListOfClosePairs(self.atomDistThreshold)
            
        # Extract first half of list, unzip, convert tuples to a list and redo overlap:
        overlapper.moveToOverlap(list(zip(*allPairings_L[0:len(allPairings_L)/2])[1]))
        #overlapper.moveToOverlap(list(zip(*distMatches_L)[1]))
        newAllPairings_L = self.getListOfClosePairs(5.0 * self.atomDistThreshold, printing = self.printingClosestPairs)
        self.getQualityValue(newAllPairings_L, printProgressiveQ = self.printProgressiveQ)
                    
    # -----------------------------------------------------------------------------
    # For each CA atom in P, find the CA atom in Q that is nearer than the shell threshold.
    # Return a list of tuples, each tuple being the distance of separation and the pair of atoms.
    # The list is sorted by increasing distance.
    def getListOfClosePairs(self, threshold, printing = False):
        caAtomsQ_L = []
        for r in self.protQ.residues:
            if r.findAtom("CA"): caAtomsQ_L.append(r.findAtom("CA"))
        shellForQ = Shell(caAtomsQ_L, 0.0, threshold)                                
        closePairs_L = []
        for r in self.protP.residues:
            if r.findAtom("CA"):
                closestCA = shellForQ.getClosestAtom(r.findAtom("CA"))
                if closestCA != None:
                    diff = linalg.norm(closestCA.coord() - r.findAtom("CA").coord())
                    closePairs_L.append((diff, (r.findAtom("CA"), closestCA)))
        closePairs_L.sort()
        # Filter out the duplicates from G:
        finalClosePairs_L = []
        alreadySeen = Set()
        if printing:
            print "\n\nClose pairs of alpha carbons and corresponding distance: \n"
            print "   ", self.protQ.name, "       ", self.protP.name
        out_L = []
        for entry in closePairs_L:
            if entry[1][1] in alreadySeen: continue
            finalClosePairs_L.append(entry)
            alreadySeen.add(entry[1][1])
            if printing:
                resP = entry[1][0].residue; resQ = entry[1][1].residue
                out_L.append((resQ.id.position, resQ.type, resP.id.position, resP.type, entry[0]))
                
        if printing:
            out_L.sort()
            for tup in out_L:
                print "%6d %3s %6d %3s     %7.4f" % tup                
        return finalClosePairs_L
                                                    
    # -----------------------------------------------------------------------------
    def getQualityValue(self, allPairs_L, printProgressiveQ = False):
        if len(allPairs_L) == 0: return float("inf")
        nP = len(self.protP.residues); nQ = len(self.protQ.residues); R0 = 3.0
        if printProgressiveQ:
            print "\n\nAtom   RMSD:   Q:"
            print "pair"
            print "count\n"
        sumDiffSq = 0.0
        qVals_L = []
        for ix in range (len(allPairs_L)):
            pair = allPairs_L[ix]
            sumDiffSq += pair[0] * pair[0]
            rmsd = numpy.sqrt(sumDiffSq/float(ix + 1))
            qVal = float((ix+1)*(ix+1))/((1.0 + (rmsd/R0)*(rmsd/R0))*nP*nQ)
            qVals_L.append(qVal)
            if printProgressiveQ:
                print "%4d %7.4f %7.4f" % (ix, rmsd, qVal)
        return max(qVals_L)
    
# -----------------------------------------------------------------------------
# For a given residue, return the secondary structure type as a letter code.
def ssType(res):
    ssType = "T"                    # Turn
    if res.isHelix:  ssType = "H"   # Helix
    if res.isStrand: ssType = "S"   # Strand
    if res.phi > 0.0: ssType = "T"  # Sudden turn ==> helix breaker
    return ssType
                    
