import chimera, numpy
from chimera import Point
from numpy import zeros, array, dot, linalg

#==============================================================================
# Overlapper CLASS
#==============================================================================

class Overlapper(object):
    def __init__(self, mol):
        self.molecule = mol
        self.atomCoords_D = {}
        self.overlapCoordsP_L = []  # Overlap list for this molecule P (molecule P to be moved).
        self.overlapCoordsQ_L = []  # Overlap list for target molecule Q (P moved to target Q)
        self.weights_L = []         # Used when overlap is done with atomic mass taken into account.
        self.newOverlapCoordsP_L = []
        self.massWeighted = False
        self.centroidP = zeros(3) # Centroid of overlapCoordsP_L
        self.centroidQ = zeros(3) # Centroid of overlapCoordsQ_L
        self.rotationMatrix = zeros((3,3))

        for a in self.molecule.atoms:
            self.atomCoords_D[a] = a.coord() # Saving original coordinates in case they are needed.
            
    # ----------------------------------------------------------------------
    def moveToOverlap(self, pairs_L, massWeighted = False):
        self.massWeighted = massWeighted
        # Get lists of coordinates:
        # We assume the first entry of a pair refers to the self molecule and
        # the second entry refers to the target protein.
        self.overlapCoordsP_L = []
        self.overlapCoordsQ_L = []        
        totalWeight = 0.0
        for pair in pairs_L:
            self.overlapCoordsP_L.append(getCoords(pair[0]))
            self.overlapCoordsQ_L.append(getCoords(pair[1]))
            if self.massWeighted:
                self.weights_L.append(pair[0].element.mass)
                totalWeight += pair[0].element.mass
                
        # Normalize the weights if mass weights are being ued.
        if self.massWeighted: self.weights_L = [x/totalWeight for x in self.weights_L]

        if self.massWeighted:
            # Mass weighted can only be used if the pairs_L list contains atoms pairs.
            self.centroidP = self.weightedCentroid(self.overlapCoordsP_L)
            self.centroidQ = self.weightedCentroid(self.overlapCoordsQ_L)
        else:
            self.centroidP = sum(self.overlapCoordsP_L)/len(pairs_L)
            self.centroidQ = sum(self.overlapCoordsQ_L)/len(pairs_L)

        # Compute shifted cverlap coords (centroids at origin):
        shiftedOverlapCoordsP_L = []
        shiftedOverlapCoordsQ_L = []
        for i in range(len(pairs_L)):
            shiftedOverlapCoordsP_L.append(self.overlapCoordsP_L[i] - self.centroidP)
            shiftedOverlapCoordsQ_L.append(self.overlapCoordsQ_L[i] - self.centroidQ)

        self.rotationMatrix = self.computeRotationMatrix(shiftedOverlapCoordsP_L, shiftedOverlapCoordsQ_L)

        # Apply the transformation to all atoms in the molecule:
        for a in self.molecule.atoms:
            newCoords = dot(self.rotationMatrix, array(a.coord()) - self.centroidP) + self.centroidQ
            a.setCoord(Point(newCoords[0], newCoords[1], newCoords[2])) 

    #-------------------------------------------------------------------------
    def rmsdForOverlap(self):
        if len(self.overlapCoordsQ_L) == 0:
            print "RMSD cannot be calculated.  First execute moveToOverlap method."
            return

        sumSquaresDeviations = 0.0
        w = 1.0
        # Apply the transformation to all contents of overlapCoordsP_L so that we can
        # compute the RMSD of the overlapped atoms.
        for ix in range(len(self.overlapCoordsP_L)):
            newCoords = dot(self.rotationMatrix, self.overlapCoordsP_L[ix] - self.centroidP) + self.centroidQ
            if self.massWeighted: w = self.weights_L[ix]
            sumSquaresDeviations += w * numpy.linalg.norm(newCoords - self.overlapCoordsQ_L[ix])**2
        if self.massWeighted:
            return numpy.sqrt(sumSquaresDeviations)
        else:
            return numpy.sqrt(sumSquaresDeviations/len(self.overlapCoordsP_L))

    #-------------------------------------------------------------------------
    def undoMove(self):
        for a in self.molecule.atoms:
            a.setCoord(self.atomCoords_D[a])


    # -----------------------------------------------------------------------------
    # Function to compute the mass weighted centroid of the atoms in the list.
    def weightedCentroid(self, aCoords_L):
        sum = zeros(3, float)
        for i in range(len(aCoords_L)):
            sum += array(aCoords_L[i])*self.weights_L[i]
        return sum
          


    #-------------------------------------------------------------------------
    def computeRotationMatrix(self, coordsP_L, coordsQ_L):
        coordsP_A = zeros((3,len(coordsP_L)), float)
        coordsQ_A = zeros((3,len(coordsQ_L)), float)
        
        for ix in range(len(coordsP_L)):
            coordsP_A[:, ix] = coordsP_L[ix]
            coordsQ_A[:, ix] = coordsQ_L[ix]
            if self.massWeighted: coordsQ_A[:, ix] = coordsQ_L[ix]*self.weights_L[ix]

        c_A = dot(coordsQ_A, coordsP_A.transpose())
        u, s, vt = linalg.svd(c_A)

        #NOTE:  we are assuming that s has singular values in descending order.
        rotMatrix = dot(u,vt)
        if linalg.det(rotMatrix) < 0:
            rotMatrix = dot(u*array([1.0, 1.0, -1.0]), vt)

        return rotMatrix

# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# Given an atom object or an array object this function returns the coordinates.
def getCoords(atomORarray):
    if type(atomORarray) is chimera.Point: coords = array(atomORarray)
    if type(atomORarray) is chimera.Atom:  coords = array(atomORarray.coord())
    if type(atomORarray) is numpy.ndarray: coords = atomORarray
    if not(type(atomORarray) is chimera.Atom or
           type(atomORarray) is numpy.ndarray or
           type(atomORarray) is chimera.Point):
        print "Bad argument type in getCoords function call."
        return None
    return coords

