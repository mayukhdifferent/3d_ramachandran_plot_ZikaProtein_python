import chimera, numpy
from numpy import zeros

b62_L = [[ 4],
         [-1, 5],
         [-2, 0, 6],
         [-2,-2, 1, 6],
         [ 0,-3,-3,-3, 9],
         [-1, 1, 0, 0,-3, 5],
         [-1, 0, 0, 2,-4, 2, 5],
         [ 0,-2, 0,-1,-3,-2,-2, 6],
         [-2, 0, 1,-1,-3, 0, 0,-2, 8],
         [-1,-3,-3,-3,-1,-3,-3,-4,-3, 4],
         [-1,-2,-3,-4,-1,-2,-3,-4,-3, 2, 4],
         [-1, 2, 0,-1,-3, 1, 1,-2,-1,-3,-2, 5],
         [-1,-1,-2,-3,-1, 0,-2,-3,-2, 1, 2,-1, 5],
         [-2,-3,-3,-3,-2,-3,-3,-3,-1, 0, 0,-3, 0, 6],
         [-1,-2,-2,-1,-3,-1,-1,-2,-2,-3,-3,-1,-2,-4, 7],
         [ 1,-1, 1, 0,-1, 0, 0, 0,-1,-2,-2, 0,-1,-2,-1, 4],
         [ 0,-1, 0,-1,-1,-1,-1,-2,-2,-1,-1,-1,-1,-2,-1, 1, 5],
         [-3,-3,-4,-4,-2,-2,-3,-2,-2,-3,-2,-3,-1, 1,-4,-3,-2,11],
         [-2,-2,-2,-3,-2,-1,-2,-3, 2,-1,-1,-2,-1, 3,-3,-2,-2, 2, 7],
         [ 0,-3,-3,-3,-1,-2,-2,-3,-3, 3, 1,-2, 1,-1,-2,-2, 0,-3,-1, 4]]


t2ix_D = {"ALA": 0,"ARG": 1,"ASN": 2,"ASP": 3,"CYS": 4,"GLN": 5,"GLU": 6,"GLY": 7,"HIS": 8,"ILE": 9,
          "LEU":10,"LYS":11,"MET":12,"PHE":13,"PRO":14,"SER":15,"THR":16,"TRP":17,"TYR":18,"VAL":19}

def b62(resAtype, resBtype):
    ixPair = (t2ix_D[resAtype], t2ix_D[resBtype])
    return b62_L[max(ixPair)][min(ixPair)]

#==============================================================================
# SequencesLocalAlignment CLASS
#==============================================================================

class SequencesLocalAlignment(object):
    def __init__(self, resP_L, resQ_L, penalty = 4):
        # This function computes a local alignment for two residue lists (not character sequences!).
        # Results are stored in the alignment_L list.  Gaps are not necessary since we only need
        # the residues that have been aligned.
        self.resP_L = resP_L
        self.resQ_L = resQ_L
        self.penalty = penalty
        self.alignment_L = []

        # Fill in the score matrix and track the largest element.
        sw = zeros((len(self.resP_L) + 1, len(self.resQ_L) + 1), int)
        maxVal = 0;
        for i in range(1, len(self.resP_L) + 1):
            for j in range(1, len(self.resQ_L) + 1):
                sw[i,j] = max(sw[i-1,j-1] + b62(self.resP_L[i-1].type, self.resQ_L[j-1].type),
                              sw[i-1,j] - self.penalty,
                              sw[i,j-1] - self.penalty,
                              0)
                if sw[i,j] >= maxVal:
                    maxVal = sw[i,j]
                    maxLoc = [i, j]

        self.maxScore = maxVal
        # Traceback:
        i = maxLoc[0]; j = maxLoc[1]
        while sw[i,j] > 0:
            if sw[i,j] == sw[i-1,j-1] + b62(self.resP_L[i-1].type, self.resQ_L[j-1].type):
                self.alignment_L.append((resP_L[i-1], resQ_L[j-1]))  # Note that indexing is shifted for input array
                                                                        # relative to indexing of score array.
                i -= 1; j -= 1
            if sw[i,j] == sw[i-1,j] - self.penalty: i -= 1
            if sw[i,j] == sw[i,j-1] - self.penalty: j -= 1

        self.alignment_L.reverse() # Not really needed for structural overlap but helps debugging.
            
    def maximumScore(self):
        return self.maxScore



